// Admin Panel JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Configuração do layout admin
    const adminLayout = document.querySelector('.admin-layout');
    
    // Definir o layout como não colapsado por padrão
    if (adminLayout && adminLayout.classList.contains('sidebar-collapsed')) {
        adminLayout.classList.remove('sidebar-collapsed');
    }
    
    // Profile Dropdown
    const profileButton = document.querySelector('.profile-button');
    const dropdownMenu = document.querySelector('.dropdown-menu');
    
    if (profileButton && dropdownMenu) {
        profileButton.addEventListener('click', function(e) {
            e.stopPropagation();
            dropdownMenu.classList.toggle('show');
        });
        
        document.addEventListener('click', function(e) {
            if (!profileButton.contains(e.target) && !dropdownMenu.contains(e.target)) {
                dropdownMenu.classList.remove('show');
            }
        });
    }
    
    // Settings Tabs Navigation
    const settingsTabs = document.querySelectorAll('.settings-tabs a');
    const settingsCards = document.querySelectorAll('.settings-section > .card');
    
    if (settingsTabs.length > 0 && settingsCards.length > 0) {
        // Show the first tab by default
        const defaultTab = document.querySelector('.settings-tabs a.active');
        if (defaultTab) {
            const targetId = defaultTab.getAttribute('href').substring(1);
            const targetCard = document.getElementById(targetId);
            
            if (targetCard) {
                targetCard.style.display = 'block';
            } else {
                // If no target found, show the first card
                settingsCards[0].style.display = 'block';
            }
        } else {
            // If no active tab, show the first card
            settingsCards[0].style.display = 'block';
        }
        
        // Handle tab clicks
        settingsTabs.forEach(tab => {
            tab.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Remove active class from all tabs
                settingsTabs.forEach(t => t.classList.remove('active'));
                
                // Add active class to clicked tab
                this.classList.add('active');
                
                // Hide all cards
                settingsCards.forEach(card => {
                    card.style.display = 'none';
                });
                
                // Show the target card
                const targetId = this.getAttribute('href').substring(1);
                const targetCard = document.getElementById(targetId);
                
                if (targetCard) {
                    targetCard.style.display = 'block';
                } else if (targetId === 'geral') {
                    // Special case for 'geral' which might not have an ID
                    settingsCards[0].style.display = 'block';
                }
            });
        });
    }
    
    // File Upload Preview
    const fileUpload = document.getElementById('logo-upload');
    const fileName = document.querySelector('.file-name');
    const logoPreview = document.getElementById('logo-preview-img');
    
    if (fileUpload && fileName) {
        fileUpload.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                const file = this.files[0];
                fileName.textContent = file.name;
                
                // Verificar se o arquivo é uma imagem
                if (file.type.match('image.*')) {
                    const reader = new FileReader();
                    
                    reader.onload = function(e) {
                        if (logoPreview) {
                            logoPreview.src = e.target.result;
                            
                            // Adicionar classe de animação
                            logoPreview.classList.add('logo-preview-animation');
                            setTimeout(() => {
                                logoPreview.classList.remove('logo-preview-animation');
                            }, 500);
                        }
                    }
                    
                    reader.readAsDataURL(file);
                }
                
                // Adicionar classe para mostrar que o arquivo foi selecionado
                const uploadContainer = document.querySelector('.logo-upload-container');
                if (uploadContainer) {
                    uploadContainer.classList.add('file-selected');
                }
            }
        });
    }
    
    // Logout functionality
    const logoutBtn = document.getElementById('logout-btn');
    const dropdownLogout = document.getElementById('dropdown-logout');
    
    const handleLogout = function(e) {
        e.preventDefault();
        // Here you would typically make an API call to logout
        // For demo purposes, we'll just redirect to the login page
        window.location.href = '../login.html';
    };
    
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
    
    if (dropdownLogout) {
        dropdownLogout.addEventListener('click', handleLogout);
    }
});
