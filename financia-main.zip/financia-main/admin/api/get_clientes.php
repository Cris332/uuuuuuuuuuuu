<?php
header('Content-Type: application/json');

// Caminho absoluto para o arquivo de configuração
$configPath = dirname(dirname(dirname(__FILE__))) . '/config.php';
require_once $configPath;

try {
    // Query para buscar clientes e suas informações
    $query = "
        SELECT 
            c.id,
            c.nome,
            c.email,
            c.telefone,
            c.data_cadastro,
            COUNT(DISTINCT a.id) as total_agendamentos,
            MAX(a.data) as ultimo_agendamento,
            AVG(a.avaliacao) as media_avaliacoes,
            COUNT(DISTINCT CASE WHEN a.avaliacao IS NOT NULL THEN a.id END) as total_avaliacoes,
            GROUP_CONCAT(DISTINCT s.nome) as servicos_utilizados
        FROM clientes c
        LEFT JOIN agendamentos a ON c.id = a.cliente_id
        LEFT JOIN servicos s ON a.servico_id = s.id
        GROUP BY c.id
        ORDER BY c.nome
    ";

    $stmt = $pdo->prepare($query);
    $stmt->execute();
    $clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Formatar dados para o frontend
    $clientesFormatados = array_map(function($cliente) {
        // Formatar data de cadastro
        $dataCadastro = new DateTime($cliente['data_cadastro']);
        
        // Formatar último agendamento
        $ultimoAgendamento = $cliente['ultimo_agendamento'] 
            ? (new DateTime($cliente['ultimo_agendamento']))->format('d/m/Y')
            : null;

        // Formatar avaliação média
        $mediaAvaliacoes = $cliente['media_avaliacoes'] 
            ? number_format($cliente['media_avaliacoes'], 1) 
            : '0.0';

        // Formatar serviços utilizados
        $servicosUtilizados = $cliente['servicos_utilizados'] 
            ? array_unique(explode(',', $cliente['servicos_utilizados']))
            : [];

        return [
            'id' => $cliente['id'],
            'nome' => $cliente['nome'],
            'email' => $cliente['email'],
            'telefone' => $cliente['telefone'],
            'data_cadastro' => $dataCadastro->format('d/m/Y'),
            'dias_desde_cadastro' => $dataCadastro->diff(new DateTime())->days,
            'total_agendamentos' => (int)$cliente['total_agendamentos'],
            'ultimo_agendamento' => $ultimoAgendamento,
            'avaliacao' => $mediaAvaliacoes,
            'total_avaliacoes' => (int)$cliente['total_avaliacoes'],
            'servicos_utilizados' => $servicosUtilizados
        ];
    }, $clientes);

    echo json_encode([
        'success' => true,
        'clientes' => $clientesFormatados
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Erro ao buscar clientes: ' . $e->getMessage()
    ]);
}
