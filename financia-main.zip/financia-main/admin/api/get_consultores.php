<?php
header('Content-Type: application/json');
// Caminho absoluto para o arquivo de configuração
$configPath = dirname(dirname(dirname(__FILE__))) . '/config.php';
require_once $configPath;

try {
    // Query para buscar consultores e seus serviços
    $query = "
        SELECT 
            c.id,
            c.nome,
            c.email,
            c.telefone,
            c.especialidades,
            c.disponibilidade,
            c.status,
            COUNT(DISTINCT a.id) as total_agendamentos,
            AVG(a.avaliacao) as media_avaliacoes,
            COUNT(DISTINCT CASE WHEN a.avaliacao IS NOT NULL THEN a.id END) as total_avaliacoes,
            GROUP_CONCAT(DISTINCT s.id) as servicos_ids,
            GROUP_CONCAT(DISTINCT s.nome) as servicos_nomes
        FROM consultores c
        LEFT JOIN consultores_servicos cs ON c.id = cs.consultor_id
        LEFT JOIN servicos s ON cs.servico_id = s.id
        LEFT JOIN agendamentos a ON c.id = a.consultor_id 
            AND MONTH(a.data) = MONTH(CURRENT_DATE)
            AND YEAR(a.data) = YEAR(CURRENT_DATE)
        GROUP BY c.id
        ORDER BY c.nome
    ";

    $stmt = $pdo->prepare($query);
    $stmt->execute();
    $consultores = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Formatar dados para o frontend
    $consultoresFormatados = array_map(function($consultor) {
        // Tratar serviços
        $servicos = [];
        if ($consultor['servicos_ids'] && $consultor['servicos_nomes']) {
            $ids = explode(',', $consultor['servicos_ids']);
            $nomes = explode(',', $consultor['servicos_nomes']);
            $servicos = array_combine($ids, $nomes);
        }

        // Tratar avaliações
        $mediaAvaliacoes = $consultor['media_avaliacoes'] ? 
            number_format($consultor['media_avaliacoes'], 1) : '0.0';

        return [
            'id' => $consultor['id'],
            'nome' => $consultor['nome'],
            'email' => $consultor['email'],
            'telefone' => $consultor['telefone'],
            'especialidades' => $consultor['especialidades'],
            'disponibilidade' => $consultor['disponibilidade'],
            'status' => $consultor['status'],
            'total_agendamentos' => (int)$consultor['total_agendamentos'],
            'avaliacao' => $mediaAvaliacoes,
            'total_avaliacoes' => (int)$consultor['total_avaliacoes'],
            'servicos' => $servicos
        ];
    }, $consultores);

    echo json_encode([
        'success' => true,
        'consultores' => $consultoresFormatados
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Erro ao buscar consultores: ' . $e->getMessage()
    ]);
}
