<?php
require_once '../../config.php';
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['admin_id'])) {
    header('HTTP/1.0 403 Forbidden');
    exit('Acesso negado');
}

header('Content-Type: application/json');

try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Recebe os dados do POST
    $data = json_decode(file_get_contents('php://input'), true);

    // Verifica se há upload de imagem
    if (isset($_FILES['logo'])) {
        $uploadDir = '../uploads/';
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $fileInfo = pathinfo($_FILES['logo']['name']);
        $extension = strtolower($fileInfo['extension']);
        
        // Verifica extensão permitida
        if (in_array($extension, ['jpg', 'jpeg', 'png', 'gif'])) {
            $newFileName = 'logo_' . time() . '.' . $extension;
            $uploadFile = $uploadDir . $newFileName;
            
            if (move_uploaded_file($_FILES['logo']['tmp_name'], $uploadFile)) {
                $data['logo_url'] = 'uploads/' . $newFileName;
            }
        }
    }

    // Atualiza as configurações da empresa
    $stmt = $pdo->prepare("
        INSERT INTO empresa_config (
            nome_empresa, 
            cnpj, 
            telefone, 
            email, 
            endereco, 
            logo_url, 
            cor_primaria, 
            cor_secundaria,
            horario_funcionamento,
            facebook_url,
            instagram_url,
            linkedin_url,
            whatsapp
        ) VALUES (
            :nome_empresa,
            :cnpj,
            :telefone,
            :email,
            :endereco,
            :logo_url,
            :cor_primaria,
            :cor_secundaria,
            :horario_funcionamento,
            :facebook_url,
            :instagram_url,
            :linkedin_url,
            :whatsapp
        ) ON DUPLICATE KEY UPDATE
            nome_empresa = VALUES(nome_empresa),
            cnpj = VALUES(cnpj),
            telefone = VALUES(telefone),
            email = VALUES(email),
            endereco = VALUES(endereco),
            logo_url = COALESCE(VALUES(logo_url), logo_url),
            cor_primaria = VALUES(cor_primaria),
            cor_secundaria = VALUES(cor_secundaria),
            horario_funcionamento = VALUES(horario_funcionamento),
            facebook_url = VALUES(facebook_url),
            instagram_url = VALUES(instagram_url),
            linkedin_url = VALUES(linkedin_url),
            whatsapp = VALUES(whatsapp)
    ");

    $stmt->execute([
        ':nome_empresa' => $data['nome_empresa'],
        ':cnpj' => $data['cnpj'],
        ':telefone' => $data['telefone'],
        ':email' => $data['email'],
        ':endereco' => $data['endereco'],
        ':logo_url' => $data['logo_url'] ?? null,
        ':cor_primaria' => $data['cor_primaria'],
        ':cor_secundaria' => $data['cor_secundaria'],
        ':horario_funcionamento' => $data['horario_funcionamento'],
        ':facebook_url' => $data['facebook_url'],
        ':instagram_url' => $data['instagram_url'],
        ':linkedin_url' => $data['linkedin_url'],
        ':whatsapp' => $data['whatsapp']
    ]);

    echo json_encode(['success' => true, 'message' => 'Configurações atualizadas com sucesso']);

} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro ao salvar configurações: ' . $e->getMessage()]);
}
