<?php
header('Content-Type: application/json');
require_once '../../config.php';

try {
    // Receber dados do POST
    $data = json_decode(file_get_contents('php://input'), true);

    if (!isset($data['nome']) || !isset($data['email']) || !isset($data['telefone']) || 
        !isset($data['especialidades']) || !isset($data['disponibilidade']) || !isset($data['servicos'])) {
        throw new Exception('Dados incompletos');
    }

    // Iniciar transação
    $pdo->beginTransaction();

    // Inserir consultor
    $stmt = $pdo->prepare("
        INSERT INTO consultores 
        (nome, email, telefone, especialidades, disponibilidade, status, avaliacao_media, total_agendamentos) 
        VALUES (?, ?, ?, ?, ?, 'ativo', 0.0, 0)
    ");

    $stmt->execute([
        $data['nome'],
        $data['email'],
        $data['telefone'],
        $data['especialidades'],
        $data['disponibilidade']
    ]);

    $consultor_id = $pdo->lastInsertId();

    // Inserir relações consultor-serviço
    $stmt = $pdo->prepare("INSERT INTO consultores_servicos (consultor_id, servico_id) VALUES (?, ?)");
    foreach ($data['servicos'] as $servico_id) {
        $stmt->execute([$consultor_id, $servico_id]);
    }

    // Confirmar transação
    $pdo->commit();        echo json_encode([
            'success' => true,
            'message' => 'Consultor adicionado com sucesso',
            'consultorId' => $consultor_id
        ]);

} catch (Exception $e) {
    if (isset($pdo)) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
