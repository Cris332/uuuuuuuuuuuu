<?php
header('Content-Type: application/json');
require_once '../../config.php';

// Verificar se é uma requisição POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Método não permitido'
    ]);
    exit;
}

// Obter dados do corpo da requisição
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['consultor_id']) || !isset($data['status'])) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Dados inválidos'
    ]);
    exit;
}

$consultorId = (int)$data['consultor_id'];
$status = strtolower($data['status']);

// Validar status
if (!in_array($status, ['ativo', 'inativo'])) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Status inválido'
    ]);
    exit;
}

try {
    // Atualizar status do consultor
    $query = "UPDATE consultores SET status = ? WHERE id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$status, $consultorId]);

    if ($stmt->rowCount() === 0) {
        throw new Exception('Consultor não encontrado');
    }

    echo json_encode([
        'success' => true,
        'message' => 'Status atualizado com sucesso'
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Erro ao atualizar status: ' . $e->getMessage()
    ]);
}
