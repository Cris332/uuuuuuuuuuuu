document.addEventListener('DOMContentLoaded', function() {
    console.log('appointments.js: Script carregado com sucesso');
    let currentPage = 1;
    let perPage = 6;
    let consultantId = 0;
    let status = '';
    let monthYear = '06-2025';
    let searchQuery = '';

    // Elementos do DOM
    const tableBody = document.querySelector('.appointments-table');
    const consultantSelect = document.querySelector('.filters select:nth-child(1)');
    const statusSelect = document.querySelector('.filters select:nth-child(2)');
    const monthSelect = document.querySelector('.month-select');
    const searchInput = document.querySelector('.search-box input');
    const exportBtn = document.querySelector('.actions button');
    const paginationControls = document.querySelector('.pagination-controls');
    const paginationInfo = document.querySelector('.pagination-info');
    const perPageSelect = document.querySelector('.pagination-options select');
    const selectAllCheckbox = document.querySelector('.table-header .table-checkbox input');

    // Verificar se os elementos existem
    if (!tableBody || !consultantSelect || !statusSelect || !monthSelect || !searchInput || !paginationControls || !paginationInfo || !perPageSelect) {
        console.error('appointments.js: Um ou mais elementos do DOM não foram encontrados');
        alert('Erro: Estrutura da página inválida. Verifique o console.');
        return;
    }

    // Inicializar
    function initAppointments() {
        console.log('appointments.js: Inicializando...');
        loadData();
        setupEventListeners();
    }

    // Carregar dados
    function loadData() {
        const params = new URLSearchParams({
            consultant_id: consultantId,
            status: status,
            month_year: monthYear,
            search: searchQuery,
            page: currentPage,
            per_page: perPage
        });
        console.log('appointments.js: Carregando dados com parâmetros:', params.toString());

        fetch(`../appointments_data.php?${params.toString()}`)
            .then(response => {
                console.log('appointments.js: Status da requisição:', response.status);
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('appointments.js: Dados recebidos:', data);
                if (data.error) {
                    console.error('Erro do servidor:', data.error);
                    alert('Erro ao carregar dados: ' + data.error);
                    return;
                }
                updateFilters(data.consultants, data.months);
                updateTable(data.appointments);
                updatePagination(data.total_records, data.current_page, data.per_page);
            })
            .catch(error => {
                console.error('appointments.js: Erro ao carregar dados:', error);
                alert('Erro ao carregar dados: ' + error.message);
            });
    }

    // Atualizar filtros
    function updateFilters(consultants, months) {
        console.log('appointments.js: Atualizando filtros:', consultants, months);
        consultantSelect.innerHTML = '<option value="0">Todos os consultores</option>';
        consultants.forEach(consultant => {
            const option = document.createElement('option');
            option.value = consultant.id;
            option.textContent = consultant.nome;
            if (parseInt(consultant.id) === consultantId) option.selected = true;
            consultantSelect.appendChild(option);
        });

        statusSelect.innerHTML = `
            <option value="">Todos os status</option>
            <option value="pendente" ${status === 'pendente' ? 'selected' : ''}>Pendente</option>
            <option value="confirmado" ${status === 'confirmado' ? 'selected' : ''}>Confirmado</option>
            <option value="cancelado" ${status === 'cancelado' ? 'selected' : ''}>Cancelado</option>
            <option value="concluido" ${status === 'concluido' ? 'selected' : ''}>Concluído</option>
        `;

        monthSelect.innerHTML = '<option value="">Todos os meses</option>';
        months.forEach(month => {
            const option = document.createElement('option');
            option.value = month;
            const [m, y] = month.split('-');
            const monthName = new Date(y, m - 1).toLocaleString('pt-BR', { month: 'long' });
            option.textContent = `${monthName.charAt(0).toUpperCase() + monthName.slice(1)} ${y}`;
            if (month === monthYear) option.selected = true;
            monthSelect.appendChild(option);
        });
    }

    // Atualizar tabela
    function updateTable(appointments) {
        console.log('appointments.js: Atualizando tabela com:', appointments);
        const header = tableBody.querySelector('.table-header');
        tableBody.innerHTML = '';
        tableBody.appendChild(header);

        appointments.forEach(appt => {
            const row = document.createElement('div');
            row.classList.add('table-row');

            const statusClass = {
                'pendente': 'pending',
                'confirmado': 'confirmed',
                'cancelado': 'cancelled',
                'concluido': 'confirmed'
            }[appt.status] || 'pending';

            const consultantColor = {
                1: 'blue', // Carlos Rodrigues
                2: 'green' // Ana Oliveira
            }[appt.consultor_id] || 'purple';

            row.innerHTML = `
                <div class="table-cell table-checkbox" data-label="Selecionar">
                    <input type="checkbox" data-id="${appt.id}">
                </div>
                <div class="table-cell" data-label="Cliente">
                    <div class="user-info">
                        <div class="user-avatar">${appt.avatar}</div>
                        <div class="user-details">
                            <div class="user-name">${appt.cliente_nome}</div>
                            <div class="user-email">${appt.cliente_email}</div>
                        </div>
                    </div>
                </div>
                <div class="table-cell" data-label="Consultor">
                    <div class="consultant-info">
                        <span class="consultant-indicator ${consultantColor}"></span>
                        ${appt.consultor_nome}
                    </div>
                </div>
                <div class="table-cell" data-label="Serviço">${appt.servico_nome}</div>
                <div class="table-cell" data-label="Data">${appt.data}</div>
                <div class="table-cell" data-label="Horário">${appt.horario}</div>
                <div class="table-cell" data-label="Status">
                    <span class="status-badge ${statusClass}">${appt.status.charAt(0).toUpperCase() + appt.status.slice(1)}</span>
                </div>
                <div class="table-cell text-center" data-label="Ações">
                    <button class="btn-icon edit" data-id="${appt.id}"><i class="fas fa-edit"></i></button>
                    <button class="btn-icon delete" data-id="${appt.id}"><i class="fas fa-trash"></i></button>
                </div>
            `;
            tableBody.appendChild(row);
        });

        setupActionButtons();
    }

    // Atualizar paginação
    function updatePagination(totalRecords, currentPage, perPage) {
        console.log('appointments.js: Atualizando paginação:', { totalRecords, currentPage, perPage });
        const totalPages = perPage === 0 ? 1 : Math.ceil(totalRecords / perPage);
        paginationControls.innerHTML = `
            <button class="pagination-btn" ${currentPage === 1 ? 'disabled' : ''}><i class="fas fa-chevron-left"></i></button>
        `;
        
        for (let i = 1; i <= totalPages; i++) {
            paginationControls.innerHTML += `
                <button class="pagination-btn ${i === currentPage ? 'active' : ''}">${i}</button>
            `;
        }

        paginationControls.innerHTML += `
            <button class="pagination-btn" ${currentPage === totalPages ? 'disabled' : ''}><i class="fas fa-chevron-right"></i></button>
        `;

        const start = totalRecords === 0 ? 0 : ((currentPage - 1) * perPage) + 1;
        const end = perPage === 0 ? totalRecords : Math.min(currentPage * perPage, totalRecords);
        paginationInfo.innerHTML = `Mostrando <span>${start}-${end}</span> de <span>${totalRecords}</span> agendamentos`;

        setupPaginationEvents();
    }

    // Configurar eventos
    function setupEventListeners() {
        console.log('appointments.js: Configurando eventos');
        consultantSelect.addEventListener('change', () => {
            consultantId = parseInt(consultantSelect.value);
            currentPage = 1;
            console.log('appointments.js: Filtro de consultor alterado:', consultantId);
            loadData();
        });

        statusSelect.addEventListener('change', () => {
            status = statusSelect.value;
            currentPage = 1;
            console.log('appointments.js: Filtro de status alterado:', status);
            loadData();
        });

        monthSelect.addEventListener('change', () => {
            monthYear = monthSelect.value;
            currentPage = 1;
            console.log('appointments.js: Filtro de mês alterado:', monthYear);
            loadData();
        });

        searchInput.addEventListener('input', debounce(() => {
            searchQuery = searchInput.value.trim();
            currentPage = 1;
            console.log('appointments.js: Busca alterada:', searchQuery);
            loadData();
        }, 300));

        perPageSelect.addEventListener('change', () => {
            perPage = perPageSelect.value === 'Todos' ? 0 : parseInt(perPageSelect.value);
            currentPage = 1;
            console.log('appointments.js: Itens por página alterado:', perPage);
            loadData();
        });

        exportBtn.addEventListener('click', () => {
            console.log('appointments.js: Botão exportar clicado');
            alert('Funcionalidade de exportação será implementada em breve!');
        });

        selectAllCheckbox.addEventListener('change', () => {
            console.log('appointments.js: Checkbox de seleção total alterado:', selectAllCheckbox.checked);
            const checkboxes = document.querySelectorAll('.table-row .table-checkbox input');
            checkboxes.forEach(cb => cb.checked = selectAllCheckbox.checked);
        });
    }

    // Configurar botões de ação
    function setupActionButtons() {
        console.log('appointments.js: Configurando botões de ação');
        document.querySelectorAll('.btn-icon.edit').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = btn.dataset.id;
                console.log('appointments.js: Editando agendamento ID:', id);
                const appt = document.querySelector(`.table-row input[data-id="${id}"]`).closest('.table-row');
                const details = {
                    id: id,
                    cliente: appt.querySelector('.user-name').textContent,
                    consultor: appt.querySelector('.consultant-info').textContent.trim(),
                    servico: appt.querySelector('.table-cell:nth-child(4)').textContent,
                    data: appt.querySelector('.table-cell:nth-child(5)').textContent,
                    horario: appt.querySelector('.table-cell:nth-child(6)').textContent,
                    status: appt.querySelector('.status-badge').textContent
                };
                alert(`Editar Agendamento ID ${id}:\nCliente: ${details.cliente}\nConsultor: ${details.consultor}\nServiço: ${details.servico}\nData: ${details.data}\nHorário: ${details.horario}\nStatus: ${details.status}`);
            });
        });

        document.querySelectorAll('.btn-icon.delete').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = btn.dataset.id;
                console.log('appointments.js: Cancelando agendamento ID:', id);
                if (confirm('Deseja cancelar este agendamento?')) {
                    fetch('../appointments_data.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ action: 'cancel', id: id })
                    })
                    .then(response => {
                        console.log('appointments.js: Status do cancelamento:', response.status);
                        return response.json();
                    })
                    .then(data => {
                        console.log('appointments.js: Resposta do cancelamento:', data);
                        if (data.success) {
                            alert('Agendamento cancelado com sucesso!');
                            loadData();
                        } else {
                            alert('Erro ao cancelar agendamento: ' + (data.error || 'Erro desconhecido'));
                        }
                    })
                    .catch(error => {
                        console.error('appointments.js: Erro ao cancelar:', error);
                        alert('Erro ao cancelar agendamento: ' + error.message);
                    });
                }
            });
        });
    }

    // Configurar eventos de paginação
    function setupPaginationEvents() {
        console.log('appointments.js: Configurando eventos de paginação');
        document.querySelectorAll('.pagination-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                if (btn.querySelector('i.fa-chevron-left')) {
                    if (currentPage > 1) currentPage--;
                } else if (btn.querySelector('i.fa-chevron-right')) {
                    currentPage++;
                } else {
                    currentPage = parseInt(btn.textContent);
                }
                console.log('appointments.js: Página alterada:', currentPage);
                loadData();
            });
        });
    }

    // Função de debounce
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // Iniciar
    initAppointments();
});