document.addEventListener('DOMContentLoaded', function() {
    let currentMonth = 6; // Junho
    let currentYear = 2025;
    let currentView = 'month'; // month, week, day
    let currentConsultant = 0; // 0 = todos
    let currentService = 0; // 0 = todos
    let currentWeekStart = null;

    // Elementos do DOM
    const calendarDays = document.querySelector('.calendar-days');
    const calendarHeader = document.querySelector('.calendar-header');
    const prevMonthBtn = document.querySelector('.calendar-navigation button:first-child');
    const nextMonthBtn = document.querySelector('.calendar-navigation button:last-child');
    const viewButtons = document.querySelectorAll('.calendar-view-selector button');
    const consultantSelect = document.querySelector('.calendar-filters select:first-child');
    const serviceSelect = document.querySelector('.calendar-filters select:last-child');
    const statsItems = document.querySelectorAll('.calendar-stats .stat-item');
    const progressBar = document.querySelector('.progress-bar');
    const progressText = document.querySelector('.progress-text');
    const newAppointmentBtn = document.querySelector('.quick-actions .btn-primary');

    // Inicializar
    function initCalendar() {
        loadData();
        setupEventListeners();
    }

    // Carregar dados do backend
    function loadData() {
        const params = new URLSearchParams({
            month: currentMonth,
            year: currentYear,
            consultant_id: currentConsultant,
            service_id: currentService
        });

        fetch(`../calendar_data.php?${params.toString()}`)
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    console.error('Erro:', data.error);
                    alert('Erro ao carregar dados: ' + data.error);
                    return;
                }

                // Atualizar filtros
                updateFilters(data.consultants, data.services);

                // Atualizar estatísticas
                updateStats(data.stats);

                // Atualizar calendário
                if (currentView === 'month') {
                    renderMonthView(data.calendar);
                } else if (currentView === 'week') {
                    renderWeekView(data.calendar);
                } else {
                    renderDayView(data.calendar);
                }
            })
            .catch(error => {
                console.error('Erro ao carregar dados:', error);
                alert('Erro ao carregar dados: ' + error.message);
            });
    }

    // Atualizar filtros de consultores e serviços
    function updateFilters(consultants, services) {
        consultantSelect.innerHTML = '<option value="0">Todos os Consultores</option>';
        consultants.forEach(consultant => {
            const option = document.createElement('option');
            option.value = consultant.id;
            option.textContent = consultant.nome;
            if (consultant.id == currentConsultant) option.selected = true;
            consultantSelect.appendChild(option);
        });

        serviceSelect.innerHTML = '<option value="0">Todos os Serviços</option>';
        services.forEach(service => {
            const option = document.createElement('option');
            option.value = service.id;
            option.textContent = service.nome;
            if (service.id == currentService) option.selected = true;
            serviceSelect.appendChild(option);
        });
    }

    // Atualizar estatísticas
    function updateStats(stats) {
        statsItems[0].querySelector('.stat-value').textContent = stats.totalAppointments;
        statsItems[1].querySelector('.stat-value').textContent = stats.confirmedAppointments;
        statsItems[2].querySelector('.stat-value').textContent = stats.pendingAppointments;
        progressBar.style.width = `${stats.progress}%`;
        progressText.textContent = `${stats.progress}% do mês concluído`;
    }

    // Renderizar vista mensal
    function renderMonthView(calendar) {
        calendarDays.innerHTML = '';
        calendarHeader.style.display = 'grid';
        calendarDays.classList.remove('week-view', 'day-view');

        calendar.forEach(day => {
            const dayDiv = document.createElement('div');
            dayDiv.classList.add('day');
            if (day.inactive) dayDiv.classList.add('inactive');
            if (day.day_number == new Date().getDate() && currentMonth == 6 && currentYear == 2025) {
                dayDiv.classList.add('today');
            }

            const dayNumber = document.createElement('div');
            dayNumber.classList.add('day-number');
            dayNumber.textContent = day.day_number;
            dayDiv.appendChild(dayNumber);

            if (day.events) {
                day.events.forEach(event => {
                    const eventDiv = document.createElement('div');
                    eventDiv.classList.add('event', event.class);
                    eventDiv.dataset.consultant = event.consultant;
                    eventDiv.dataset.service = event.service;
                    eventDiv.dataset.duration = event.duration;
                    eventDiv.innerHTML = `
                        <span class="event-time">${event.time}</span>
                        <span class="event-name">${event.consultant}</span>
                    `;
                    eventDiv.addEventListener('click', () => showEventDetails(event));
                    dayDiv.appendChild(eventDiv);
                });
            }

            calendarDays.appendChild(dayDiv);
        });
    }

    // Renderizar vista semanal
    function renderWeekView(calendar) {
        calendarDays.innerHTML = '';
        calendarHeader.style.display = 'grid';
        calendarDays.classList.remove('day-view');
        calendarDays.classList.add('week-view');

        if (!currentWeekStart) {
            currentWeekStart = new Date(currentYear, currentMonth - 1, 1);
        }

        const weekDays = [];
        for (let i = 0; i < 7; i++) {
            const day = new Date(currentWeekStart);
            day.setDate(currentWeekStart.getDate() + i);
            weekDays.push(day);
        }

        weekDays.forEach(day => {
            const dayDiv = document.createElement('div');
            dayDiv.classList.add('day');
            if (day.getMonth() + 1 !== currentMonth) dayDiv.classList.add('inactive');
            if (day.getDate() == new Date().getDate() && currentMonth == 6 && currentYear == 2025) {
                dayDiv.classList.add('today');
            }

            const dayNumber = document.createElement('div');
            dayNumber.classList.add('day-number');
            dayNumber.textContent = day.getDate();
            dayDiv.appendChild(dayNumber);

            const dayData = calendar.find(d => d.day_number == day.getDate() && !d.inactive);
            if (dayData && dayData.events) {
                dayData.events.forEach(event => {
                    const eventDiv = document.createElement('div');
                    eventDiv.classList.add('event', event.class);
                    eventDiv.dataset.consultant = event.consultant;
                    eventDiv.dataset.service = event.service;
                    eventDiv.dataset.duration = event.duration;
                    eventDiv.innerHTML = `
                        <span class="event-time">${event.time}</span>
                        <span class="event-name">${event.consultant}</span>
                    `;
                    eventDiv.addEventListener('click', () => showEventDetails(event));
                    dayDiv.appendChild(eventDiv);
                });
            }

            calendarDays.appendChild(dayDiv);
        });
    }

    // Renderizar vista diária
    function renderDayView(calendar) {
        calendarDays.innerHTML = '';
        calendarHeader.style.display = 'none';
        calendarDays.classList.remove('week-view');
        calendarDays.classList.add('day-view');

        const today = new Date(currentYear, currentMonth - 1, new Date().getDate());
        const dayData = calendar.find(d => d.day_number == today.getDate() && !d.inactive);

        const dayDiv = document.createElement('div');
        dayDiv.classList.add('day', 'full-width');

        const dayNumber = document.createElement('div');
        dayNumber.classList.add('day-number');
        dayNumber.textContent = today.getDate();
        dayDiv.appendChild(dayNumber);

        if (dayData && dayData.events) {
            dayData.events.forEach(event => {
                const eventDiv = document.createElement('div');
                eventDiv.classList.add('event', event.class);
                eventDiv.dataset.consultant = event.consultant;
                eventDiv.dataset.service = event.service;
                eventDiv.dataset.duration = event.duration;
                eventDiv.innerHTML = `
                    <span class="event-time">${event.time}</span>
                    <span class="event-name">${event.consultant} - ${event.client} (${event.service})</span>
                `;
                eventDiv.addEventListener('click', () => showEventDetails(event));
                dayDiv.appendChild(eventDiv);
            });
        }

        calendarDays.appendChild(dayDiv);
    }

    // Mostrar detalhes do evento
    function showEventDetails(event) {
        alert(`
            Agendamento ID: ${event.id}
            Consultor: ${event.consultant}
            Cliente: ${event.client}
            Serviço: ${event.service}
            Horário: ${event.time}
            Duração: ${event.duration}
            Status: ${event.status}
        `);
    }

    // Configurar eventos
    function setupEventListeners() {
        prevMonthBtn.addEventListener('click', () => {
            if (currentView === 'month') {
                currentMonth--;
                if (currentMonth < 1) {
                    currentMonth = 12;
                    currentYear--;
                }
            } else if (currentView === 'week') {
                currentWeekStart.setDate(currentWeekStart.getDate() - 7);
                currentMonth = currentWeekStart.getMonth() + 1;
                currentYear = currentWeekStart.getFullYear();
            }
            loadData();
        });

        nextMonthBtn.addEventListener('click', () => {
            if (currentView === 'month') {
                currentMonth++;
                if (currentMonth > 12) {
                    currentMonth = 1;
                    currentYear++;
                }
            } else if (currentView === 'week') {
                currentWeekStart.setDate(currentWeekStart.getDate() + 7);
                currentMonth = currentWeekStart.getMonth() + 1;
                currentYear = currentWeekStart.getFullYear();
            }
            loadData();
        });

        viewButtons.forEach(button => {
            button.addEventListener('click', () => {
                viewButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');
                currentView = button.querySelector('i').classList.contains('fa-calendar-alt') ? 'month' :
                             button.querySelector('i').classList.contains('fa-calendar-week') ? 'week' : 'day';
                if (currentView === 'week' && !currentWeekStart) {
                    currentWeekStart = new Date(currentYear, currentMonth - 1, 1);
                }
                loadData();
            });
        });

        consultantSelect.addEventListener('change', () => {
            currentConsultant = parseInt(consultantSelect.value);
            loadData();
        });

        serviceSelect.addEventListener('change', () => {
            currentService = parseInt(serviceSelect.value);
            loadData();
        });

        newAppointmentBtn.addEventListener('click', () => {
            // Redirecionar para uma página de novo agendamento (placeholder)
            alert('Funcionalidade de novo agendamento será implementada em breve!');
            // window.location.href = 'novo-agendamento.html';
        });
    }

    // Iniciar
    initCalendar();
});