document.addEventListener('DOMContentLoaded', () => {
    console.log('clients.js: Script carregado com sucesso');

    const searchInput = document.querySelector('.search-box input');
    const statusFilter = document.querySelector('.filters select:nth-child(1)');
    const serviceFilter = document.querySelector('.filters select:nth-child(2)');
    const dateButton = document.querySelector('.date-button');
    const newClientButton = document.querySelector('.btn-primary');
    const importButton = document.querySelector('.clients-controls .btn-outline:nth-child(2)');
    const exportButton = document.querySelector('.clients-controls .btn-outline:nth-child(3)');
    const tableBody = document.querySelector('.clients-table tbody');
    const paginationControls = document.querySelector('.pagination-controls');
    const paginationInfo = document.querySelector('.pagination-info');
    const limitSelect = document.querySelector('.pagination-options select');

    let currentPage = 1;
    let currentLimit = 6;

    // Carregar dados
    function loadClients(params = {}) {
        console.log('clients.js: Carregando dados com parâmetros:', params);
        fetch(`../clients_data.php?${new URLSearchParams(params)}`)
            .then(response => {
                console.log('clients.js: Status:', response.status);
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('clients.js: Dados recebidos:', data);
                if (!data.success) {
                    throw new Error(data.error || 'Erro ao carregar dados');
                }
                if (!Array.isArray(data.clients)) {
                    throw new Error('Resposta inválida: data.clients não é um array');
                }
                renderClients(data.clients);
                renderPagination(data.total_records, data.current_page, data.total_pages);
                populateServiceFilter(data.services || []);
            })
            .catch(error => {
                console.error('clients.js: Erro:', error.message);
                tableBody.innerHTML = '<tr><td colspan="8">Erro ao carregar dados: ' + error.message + '</td></tr>';
                alert(`Erro ao carregar dados: ${error.message}`);
            });
    }

    // Renderizar clientes
    function renderClients(clients) {
        console.log('clients.js: Renderizando clientes:', clients);
        tableBody.innerHTML = '';
        if (clients.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="8">Nenhum cliente encontrado</td></tr>';
            return;
        }
        clients.forEach(client => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><input type="checkbox"> #${client.id}</td>
                <td>
                    <div class="client-info">
                        <img src="https://randomuser.me/api/portraits/${client.id % 2 === 0 ? 'men' : 'women'}/${client.id % 100}.jpg" alt="${client.nome}">
                        <div>
                            <div class="client-name">${client.nome}</div>
                            <div class="client-since">Desde ${client.data_cadastro}</div>
                        </div>
                    </div>
                </td>
                <td>${client.email}</td>
                <td>${client.telefone}</td>
                <td>${client.ultimo_servico}</td>
                <td>${client.valor_total}</td>
                <td>
                    <span class="status-badge ${client.status.toLowerCase()}">${client.status.charAt(0).toUpperCase() + client.status.slice(1)}</span>
                </td>
                <td>
                    <button class="btn-icon" title="Visualizar" data-action="view" data-id="${client.id}">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn-icon" title="Editar" data-action="edit" data-id="${client.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-icon" title="Agendar" data-action="schedule" data-id="${client.id}">
                        <i class="fas fa-calendar-plus"></i>
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });
    }

    // Renderizar paginação
    function renderPagination(totalRecords, currentPage, totalPages) {
        console.log('clients.js: Renderizando paginação:', { totalRecords, currentPage, totalPages });
        paginationInfo.textContent = `Mostrando ${(currentPage - 1) * currentLimit + 1}-${Math.min(currentPage * currentLimit, totalRecords)} de ${totalRecords} clientes`;
        paginationControls.innerHTML = '';

        const prevButton = document.createElement('button');
        prevButton.className = 'btn-outline';
        prevButton.innerHTML = '<i class="fas fa-chevron-left"></i>';
        prevButton.disabled = currentPage === 1;
        prevButton.addEventListener('click', () => {
            if (currentPage > 1) {
                currentPage--;
                loadClients(getCurrentParams());
            }
        });
        paginationControls.appendChild(prevButton);

        for (let i = 1; i <= totalPages; i++) {
            const pageButton = document.createElement('button');
            pageButton.className = `btn-outline ${i === currentPage ? 'active' : ''}`;
            pageButton.textContent = i;
            pageButton.addEventListener('click', () => {
                currentPage = i;
                loadClients(getCurrentParams());
            });
            paginationControls.appendChild(pageButton);
        }

        const nextButton = document.createElement('button');
        nextButton.className = 'btn-outline';
        nextButton.innerHTML = '<i class="fas fa-chevron-right"></i>';
        nextButton.disabled = currentPage === totalPages;
        nextButton.addEventListener('click', () => {
            if (currentPage < totalPages) {
                currentPage++;
                loadClients(getCurrentParams());
            }
        });
        paginationControls.appendChild(nextButton);
    }

    // Popular filtro de serviços
    function populateServiceFilter(services) {
        console.log('clients.js: Populando filtro de serviços:', services);
        serviceFilter.innerHTML = '<option>Todos os Serviços</option>';
        services.forEach(service => {
            const option = document.createElement('option');
            option.value = service;
            option.textContent = service;
            serviceFilter.appendChild(option);
        });
    }

    // Obter parâmetros atuais
    function getCurrentParams() {
        return {
            search: searchInput.value,
            status: statusFilter.value === 'Todos os Status' ? '' : statusFilter.value.toLowerCase(),
            service: serviceFilter.value === 'Todos os Serviços' ? '' : serviceFilter.value,
            page: currentPage,
            limit: currentLimit
        };
    }

    // Event listeners
    let searchTimeout;
    searchInput.addEventListener('input', () => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            currentPage = 1;
            loadClients(getCurrentParams());
        }, 500);
    });

    statusFilter.addEventListener('change', () => {
        currentPage = 1;
        loadClients(getCurrentParams());
    });

    serviceFilter.addEventListener('change', () => {
        currentPage = 1;
        loadClients(getCurrentParams());
    });

    dateButton.addEventListener('click', () => {
        alert('Filtro por data de cadastro ainda não implementado.');
    });

    newClientButton.addEventListener('click', () => {
        alert('Funcionalidade de novo cliente ainda não implementada.');
    });

    importButton.addEventListener('click', () => {
        alert('Funcionalidade de importação ainda não implementada.');
    });

    exportButton.addEventListener('click', () => {
        alert('Funcionalidade de exportação ainda não implementada.');
    });

    limitSelect.addEventListener('change', () => {
        currentLimit = parseInt(limitSelect.value);
        currentPage = 1;
        loadClients(getCurrentParams());
    });

    tableBody.addEventListener('click', (e) => {
        const button = e.target.closest('.btn-icon');
        if (button) {
            const action = button.dataset.action;
            const id = button.dataset.id;
            const client = Array.from(tableBody.querySelectorAll('tr')).find(row => row.querySelector(`[data-id="${id}"]`));
            const name = client.querySelector('.client-name').textContent;
            switch (action) {
                case 'view':
                    alert(`Visualizar cliente ID ${id}: ${name}`);
                    break;
                case 'edit':
                    alert(`Editar cliente ID ${id}: ${name}`);
                    break;
                case 'schedule':
                    alert(`Agendar para cliente ID ${id}: ${name}`);
                    break;
            }
        }
    });

    // Carregar dados iniciais
    loadClients(getCurrentParams());
});