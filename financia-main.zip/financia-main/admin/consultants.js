document.addEventListener('DOMContentLoaded', function () {
    // Estado da aplicação
    let allConsultants = [];
    let filteredConsultants = [];

    // Elementos do DOM
    const consultantsGrid = document.querySelector('.consultants-grid');
    const statusSelect = document.querySelector('.filters select:nth-child(1)');
    const serviceSelect = document.querySelector('.filters select:nth-child(2)');
    const searchInput = document.querySelector('.search-box input');
    const newConsultantBtn = document.querySelector('.actions .btn-primary');

    // Função para carregar consultores
    function loadData() {
        setLoading(true);
        fetch('api/get_consultores.php')
            .then(response => {
                if (!response.ok) throw new Error('Erro na requisição');
                return response.json();
            })
            .then(data => {
                if (!data.success) throw new Error(data.error || 'Erro ao carregar consultores');
                allConsultants = data.consultores;
                updateDisplay();
            })
            .catch(error => {
                console.error('Erro:', error);
                consultantsGrid.innerHTML = `
                    <div class="error-state">
                        <i class="fas fa-exclamation-circle"></i>
                        <p>Erro ao carregar consultores: ${error.message}</p>
                        <button onclick="loadData()" class="btn-secondary">
                            <i class="fas fa-sync"></i> Tentar novamente
                        </button>
                    </div>
                `;
            })
            .finally(() => {
                setLoading(false);
            });
    }

    // Função para atualizar a exibição
    function updateDisplay() {
        // Aplicar filtros
        filteredConsultants = allConsultants.filter(consultor => {
            const searchTerm = searchInput.value.toLowerCase();
            const selectedStatus = statusSelect.value;
            const selectedService = serviceSelect.value;

            // Filtro de busca
            const matchesSearch =
                consultor.nome.toLowerCase().includes(searchTerm) ||
                consultor.email.toLowerCase().includes(searchTerm) ||
                consultor.especialidades.toLowerCase().includes(searchTerm);

            // Filtro de status
            const matchesStatus =
                selectedStatus === 'Todos os Status' ||
                consultor.status.toLowerCase() === selectedStatus.toLowerCase();

            // Filtro de serviço
            const matchesService =
                selectedService === 'Todos os Serviços' ||
                Object.values(consultor.servicos).includes(selectedService);

            return matchesSearch && matchesStatus && matchesService;
        });

        // Verificar se há consultores após os filtros
        if (filteredConsultants.length === 0) {
            consultantsGrid.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-user-tie"></i>
                    <p>Nenhum consultor encontrado com os filtros selecionados.</p>
                </div>
            `;
            return;
        }

        // Renderizar cards dos consultores
        consultantsGrid.innerHTML = filteredConsultants.map(consultor => `
            <div class="consultant-card" data-id="${consultor.id}">
                <div class="consultant-header">
                    <span class="status-badge ${consultor.status.toLowerCase()}">${consultor.status}</span>
                    <img src="https://randomuser.me/api/portraits/${consultor.id % 2 ? 'men' : 'women'}/${(consultor.id * 123) % 70 + 1}.jpg" 
                         alt="${consultor.nome}">
                    <h3>${consultor.nome}</h3>
                    <p>${consultor.especialidades.split(',')[0]}</p>
                </div>
                
                <div class="consultant-body">
                    <div class="consultant-details">
                        <div class="detail-row">
                            <i class="fas fa-envelope"></i>
                            <span>${consultor.email}</span>
                        </div>
                        <div class="detail-row">
                            <i class="fas fa-phone-alt"></i>
                            <span>${consultor.telefone || 'Não informado'}</span>
                        </div>
                        <div class="detail-row">
                            <i class="fas fa-clipboard-list"></i>
                            <span>${consultor.total_agendamentos} agendamentos este mês</span>
                        </div>
                        <div class="detail-row">
                            <i class="fas fa-star"></i>
                            <span>${consultor.avaliacao}/5.0 (${consultor.total_avaliacoes} avaliações)</span>
                        </div>
                    </div>
                    
                    <div class="consultant-specialties">
                        <h4>Especialidades</h4>
                        <div>
                            ${Object.values(consultor.servicos)
                .map(servico => `<span class="specialty-tag">${servico}</span>`)
                .join('')}
                        </div>
                    </div>
                    
                    <div class="consultant-actions">
                        <button class="btn-icon edit-consultant" onclick="editConsultant(${consultor.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn-icon view-schedule" onclick="viewSchedule(${consultor.id})">
                            <i class="fas fa-calendar-alt"></i>
                        </button>
                        <button class="btn-icon toggle-status" 
                                onclick="toggleStatus(${consultor.id}, '${consultor.status}')"
                                title="${consultor.status === 'ativo' ? 'Desativar' : 'Ativar'} consultor">
                            <i class="fas fa-toggle-${consultor.status === 'ativo' ? 'on' : 'off'}"></i>
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
    }

    // Função para mostrar/ocultar loading
    function setLoading(isLoading) {
        if (isLoading) {
            consultantsGrid.innerHTML = `
                <div class="loading-state">
                    <i class="fas fa-spinner fa-spin"></i>
                    <p>Carregando consultores...</p>
                </div>
            `;
        }
    }

    // Funções de ação
    window.editConsultant = function (id) {
        const consultor = allConsultants.find(c => c.id === id);
        // TODO: Implementar edição do consultor
        console.log('Editar consultor:', consultor);
    };

    window.viewSchedule = function (id) {
        window.location.href = `calendario.html?consultor=${id}`;
    };

    window.toggleStatus = function (id, currentStatus) {
        const newStatus = currentStatus === 'ativo' ? 'inativo' : 'ativo';

        if (confirm(`Deseja ${newStatus === 'ativo' ? 'ativar' : 'desativar'} este consultor?`)) {
            fetch('api/update_status.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    consultor_id: id,
                    status: newStatus
                })
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Atualizar status no array local
                        const consultor = allConsultants.find(c => c.id === id);
                        if (consultor) {
                            consultor.status = newStatus;
                            updateDisplay();
                        }
                    } else {
                        throw new Error(data.error || 'Erro ao atualizar status');
                    }
                })
                .catch(error => {
                    console.error('Erro:', error);
                    alert('Erro ao atualizar status do consultor');
                });
        }
    };

    // Configurar event listeners
    function setupEventListeners() {
        statusSelect.addEventListener('change', updateDisplay);
        serviceSelect.addEventListener('change', updateDisplay);
        searchInput.addEventListener('input', updateDisplay);
    }

    // Carregar serviços no filtro
    function loadServices() {
        fetch('../services_data.php')
            .then(response => response.json())
            .then(data => {
                if (data.success && data.servicos) {
                    serviceSelect.innerHTML = '<option>Todos os Serviços</option>' +
                        data.servicos.map(servico =>
                            `<option>${servico.nome}</option>`
                        ).join('');
                }
            })
            .catch(error => console.error('Erro ao carregar serviços:', error));
    }

    // Inicialização
    loadServices();
    setupEventListeners();
    loadData();
});