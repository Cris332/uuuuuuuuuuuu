document.addEventListener('DOMContentLoaded', function() {
    // Função para formatar o nome do dia
    function formatDayName(day) {
        const days = {
            'Mon': 'Seg', 'Tue': 'Ter', 'Wed': 'Qua', 'Thu': 'Qui',
            'Fri': 'Sex', 'Sat': 'Sáb', 'Sun': 'Dom'
        };
        return days[day] || day;
    }

    fetch('../dashboard_data.php')
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                console.error('Erro:', data.error);
                return;
            }

            // Atualiza Stats Cards
            const statsCards = document.querySelectorAll('.stats-cards .stat-card');
            statsCards[0].querySelector('h3').textContent = data.stats.appointmentsThisMonth;
            statsCards[1].querySelector('h3').textContent = `R$ ${data.stats.revenueThisMonth}`;
            statsCards[2].querySelector('h3').textContent = data.stats.newClients;
            statsCards[3].querySelector('h3').textContent = data.stats.avgRating;

            // Atualiza Agenda da Semana
            const calendarDays = document.querySelector('.calendar-days');
            calendarDays.innerHTML = '';
            for (let day = 1; day <= 7; day++) {
                const dayData = data.calendar[day];
                const dayColumn = document.createElement('div');
                dayColumn.classList.add('day-column');

                const dayHeader = document.createElement('div');
                dayHeader.classList.add('day-header');
                dayHeader.innerHTML = `
                    <span class="day-name">${formatDayName(dayData.day_name)}</span>
                    <span class="day-number">${dayData.day_number}</span>
                `;
                dayColumn.appendChild(dayHeader);

                const dayEvents = document.createElement('div');
                dayEvents.classList.add('day-events');
                dayData.events.forEach(event => {
                    const eventDiv = document.createElement('div');
                    const statusClass = {
                        'pendente': 'bg-orange',
                        'confirmado': 'bg-green',
                        'concluido': 'bg-blue'
                    }[event.status] || 'bg-blue';
                    eventDiv.classList.add('event', statusClass);
                    eventDiv.innerHTML = `
                        <span class="event-time">${event.time}</span>
                        <span class="event-title">${event.title}</span>
                    `;
                    dayEvents.appendChild(eventDiv);
                });
                dayColumn.appendChild(dayEvents);
                calendarDays.appendChild(dayColumn);
            }

            // Atualiza Atividades Recentes
            const activityList = document.querySelector('.activity-list');
            activityList.innerHTML = '';
            data.activities.forEach(activity => {
                const activityItem = document.createElement('div');
                activityItem.classList.add('activity-item');
                const iconClass = {
                    'new_appointment': 'fas fa-check bg-green',
                    'reagendamento': 'fas fa-sync-alt bg-orange',
                    'new_client': 'fas fa-user-plus bg-blue',
                    'cancelled_appointment': 'fas fa-times bg-red'
                }[activity.type] || 'fas fa-star bg-purple';
                activityItem.innerHTML = `
                    <div class="activity-icon ${iconClass}"></div>
                    <div class="activity-details">
                        <p>${activity.description}</p>
                        <p class="activity-meta">${activity.meta}</p>
                        <span class="activity-time">${activity.time}</span>
                    </div>
                `;
                activityList.appendChild(activityItem);
            });

            // Atualiza Próximos Agendamentos
            const appointmentList = document.querySelector('.appointment-list');
            appointmentList.innerHTML = '';
            data.upcoming.forEach(appt => {
                const appointmentItem = document.createElement('div');
                appointmentItem.classList.add('appointment-item');
                appointmentItem.innerHTML = `
                    <div class="appointment-time">
                        <span class="day">${appt.day}</span>
                        <span class="hour">${appt.hour}</span>
                    </div>
                    <div class="appointment-details">
                        <h4>${appt.client}</h4>
                        <p>${appt.service}</p>
                        <span class="appointment-duration"><i class="far fa-clock"></i> ${appt.duration}</span>
                    </div>
                    <div class="appointment-actions">
                        <button class="btn-icon" title="Editar" data-id="${appt.id}"><i class="fas fa-edit"></i></button>
                        <button class="btn-icon" title="Cancelar" data-id="${appt.id}"><i class="fas fa-times"></i></button>
                    </div>
                `;
                appointmentList.appendChild(appointmentItem);
            });
        })
        .catch(error => {
            console.error('Erro ao carregar dados do dashboard:', error);
        });
});