SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "-03:00";

-- Criação do banco de dados
CREATE DATABASE IF NOT EXISTS `financeconsult` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `financeconsult`;

-- Tabela: admin_users
-- Armazena usuários administrativos do painel
CREATE TABLE IF NOT EXISTS `admin_users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(50) NOT NULL,
  `password` VARCHAR(255) NOT NULL COMMENT 'Senha criptografada com password_hash',
  `email` VARCHAR(100) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  UNIQUE KEY `uk_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabela: clientes
-- Armazena informações dos clientes que fazem agendamentos
CREATE TABLE IF NOT EXISTS `clientes` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `telefone` VARCHAR(15) NOT NULL COMMENT 'Formato: (XX) XXXX-XXXX ou (XX) XXXXX-XXXX',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabela: servicos
-- Armazena os serviços oferecidos (ex.: Consultoria Financeira)
CREATE TABLE IF NOT EXISTS `servicos` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(100) NOT NULL,
  `descricao` TEXT,
  `duracao` INT NOT NULL COMMENT 'Duração em minutos',
  `preco` DECIMAL(10,2) NOT NULL,
  `status` ENUM('ativo','inativo') NOT NULL DEFAULT 'ativo',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_nome` (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabela: consultores
-- Armazena informações dos consultores financeiros
CREATE TABLE IF NOT EXISTS `consultores` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `telefone` VARCHAR(15) NOT NULL COMMENT 'Formato: (XX) XXXX-XXXX ou (XX) XXXXX-XXXX',
  `especialidades` VARCHAR(255) NOT NULL COMMENT 'Especialidades separadas por vírgula',
  `disponibilidade` VARCHAR(255) NOT NULL COMMENT 'Ex.: Seg-Sex: 09:00-18:00',
  `status` ENUM('ativo','inativo','de_ferias') NOT NULL DEFAULT 'ativo',
  `avaliacao_media` DECIMAL(3,1) DEFAULT 0.0 COMMENT 'Média de avaliações (0.0 a 5.0)',
  `total_agendamentos` INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabela: consultores_servicos
-- Relaciona consultores aos serviços que oferecem (N:N)
CREATE TABLE IF NOT EXISTS `consultores_servicos` (
  `consultor_id` INT UNSIGNED NOT NULL,
  `servico_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`consultor_id`, `servico_id`),
  CONSTRAINT `fk_cs_consultor` FOREIGN KEY (`consultor_id`) REFERENCES `consultores` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cs_servico` FOREIGN KEY (`servico_id`) REFERENCES `servicos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabela: agendamentos
-- Armazena os agendamentos feitos pelos clientes
CREATE TABLE IF NOT EXISTS `agendamentos` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `cliente_id` INT UNSIGNED NOT NULL,
  `consultor_id` INT UNSIGNED NOT NULL,
  `servico_id` INT UNSIGNED NOT NULL,
  `data_hora` DATETIME NOT NULL,
  `duracao` INT NOT NULL COMMENT 'Duração em minutos',
  `status` ENUM('pendente','confirmado','concluido','cancelado') NOT NULL DEFAULT 'pendente',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_agendamento_cliente` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_agendamento_consultor` FOREIGN KEY (`consultor_id`) REFERENCES `consultores` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_agendamento_servico` FOREIGN KEY (`servico_id`) REFERENCES `servicos` (`id`) ON DELETE CASCADE,
  INDEX `idx_agendamentos_data_hora` (`data_hora`),
  INDEX `idx_agendamentos_consultor` (`consultor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabela: avaliacoes
-- Armazena as avaliações dos consultores
CREATE TABLE IF NOT EXISTS `avaliacoes` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `consultor_id` INT UNSIGNED NOT NULL,
  `nota` FLOAT NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_avaliacao_consultor` FOREIGN KEY (`consultor_id`) REFERENCES `consultores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dados iniciais para teste
-- admin_users
INSERT INTO `admin_users` (`username`, `password`, `email`) VALUES
('admin', '$2y$10$4z3X8K9Y7W5V2Q6J1P0T8e9R0S3M2N5B7A4C6D8E9F0G1H2I3J4K5', 'admin@financeconsult.com');

-- clientes
INSERT INTO `clientes` (`nome`, `email`, `telefone`) VALUES
('João Silva', 'joao.silva@email.com', '(11) 98765-4321'),
('Maria Oliveira', 'maria.oliveira@email.com', '(21) 91234-5678');

-- servicos
INSERT INTO `servicos` (`nome`, `descricao`, `duracao`, `preco`, `status`) VALUES
('Consultoria Financeira', 'Análise completa das finanças pessoais ou empresariais.', 60, 250.00, 'ativo'),
('Planejamento de Aposentadoria', 'Elaboração de plano para aposentadoria segura.', 90, 320.00, 'ativo'),
('Consultoria de Investimentos', 'Orientação para investimentos no mercado financeiro.', 60, 280.00, 'ativo'),
('Gestão de Dívidas', 'Planejamento para quitação de dívidas.', 60, 200.00, 'inativo');

-- consultores
INSERT INTO `consultores` (`nome`, `email`, `telefone`, `especialidades`, `disponibilidade`, `status`, `avaliacao_media`, `total_agendamentos`) VALUES
('Carlos Rodrigues', 'carlos.rodrigues@email.com', '(11) 98765-4321', 'Consultoria Financeira, Planejamento de Aposentadoria, Investimentos', 'Seg-Sex: 09:00-18:00', 'ativo', 4.8, 32),
('Ana Oliveira', 'ana.oliveira@email.com', '(21) 91234-5678', 'Consultoria Financeira, Gestão de Dívidas', 'Seg-Sex: 10:00-16:00', 'ativo', 4.5, 20),
('Pedro Santos', 'pedro.santos@email.com', '(31) 99876-5432', 'Planejamento de Aposentadoria, Investimentos', 'Seg-Sex: 08:00-17:00', 'de_ferias', 4.7, 15),
('Laura Mendes', 'laura.mendes@email.com', '(41) 98765-1234', 'Consultoria Financeira, Investimentos', 'Seg-Sex: 09:00-18:00', 'inativo', 4.3, 10);

-- consultores_servicos
INSERT INTO `consultores_servicos` (`consultor_id`, `servico_id`) VALUES
(1, 1), (1, 2), (1, 3),
(2, 1), (2, 4),
(3, 2), (3, 3),
(4, 1), (4, 3);

-- agendamentos
INSERT INTO `agendamentos` (`cliente_id`, `consultor_id`, `servico_id`, `data_hora`, `duracao`, `status`) VALUES
(1, 1, 1, '2025-06-17 09:00:00', 60, 'pendente'),
(2, 2, 1, '2025-06-17 10:00:00', 60, 'confirmado'),
(1, 1, 3, '2025-06-18 14:00:00', 60, 'concluido'),
(2, 3, 2, '2025-06-19 11:00:00', 90, 'cancelado');

COMMIT;
