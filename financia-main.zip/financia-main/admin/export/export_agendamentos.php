<?php
require_once '../../config.php';
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['admin_id'])) {
    header('HTTP/1.0 403 Forbidden');
    exit('Acesso negado');
}

// Tipo de exportação (PDF ou CSV)
$type = isset($_GET['type']) ? $_GET['type'] : 'pdf';

// Filtros
$dateStart = isset($_GET['date_start']) ? $_GET['date_start'] : '';
$dateEnd = isset($_GET['date_end']) ? $_GET['date_end'] : '';
$status = isset($_GET['status']) ? $_GET['status'] : '';

try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $query = "SELECT a.*, c.nome as cliente_nome, co.nome as consultor_nome, s.nome as servico_nome 
              FROM agendamentos a 
              JOIN clientes c ON a.cliente_id = c.id 
              JOIN consultores co ON a.consultor_id = co.id 
              JOIN servicos s ON a.servico_id = s.id 
              WHERE 1=1";

    if ($dateStart) {
        $query .= " AND DATE(a.data_hora) >= :date_start";
    }
    if ($dateEnd) {
        $query .= " AND DATE(a.data_hora) <= :date_end";
    }
    if ($status) {
        $query .= " AND a.status = :status";
    }

    $stmt = $pdo->prepare($query);
    
    if ($dateStart) {
        $stmt->bindParam(':date_start', $dateStart);
    }
    if ($dateEnd) {
        $stmt->bindParam(':date_end', $dateEnd);
    }
    if ($status) {
        $stmt->bindParam(':status', $status);
    }

    $stmt->execute();
    $agendamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($type === 'csv') {
        // Configuração do cabeçalho para download do CSV
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="agendamentos.csv"');

        $output = fopen('php://output', 'w');

        // Cabeçalhos do CSV
        fputcsv($output, ['ID', 'Cliente', 'Consultor', 'Serviço', 'Data/Hora', 'Status']);

        // Dados
        foreach ($agendamentos as $agendamento) {
            fputcsv($output, [
                $agendamento['id'],
                $agendamento['cliente_nome'],
                $agendamento['consultor_nome'],
                $agendamento['servico_nome'],
                $agendamento['data_hora'],
                $agendamento['status']
            ]);
        }

        fclose($output);
    } else {
        // Gerar PDF usando TCPDF
        require_once('../../lib/tcpdf/tcpdf.php');

        $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
        
        // Configurações do documento
        $pdf->SetCreator('FinanceConsult Pro');
        $pdf->SetAuthor('Administrador');
        $pdf->SetTitle('Relatório de Agendamentos');

        // Configurações de fonte
        $pdf->SetFont('helvetica', '', 10);

        // Adiciona uma página
        $pdf->AddPage();

        // Título do relatório
        $pdf->SetFont('helvetica', 'B', 16);
        $pdf->Cell(0, 15, 'Relatório de Agendamentos', 0, true, 'C');
        $pdf->Ln(10);

        // Cabeçalhos da tabela
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(15, 7, 'ID', 1);
        $pdf->Cell(40, 7, 'Cliente', 1);
        $pdf->Cell(40, 7, 'Consultor', 1);
        $pdf->Cell(40, 7, 'Serviço', 1);
        $pdf->Cell(30, 7, 'Data/Hora', 1);
        $pdf->Cell(25, 7, 'Status', 1);
        $pdf->Ln();

        // Dados da tabela
        $pdf->SetFont('helvetica', '', 10);
        foreach ($agendamentos as $agendamento) {
            $pdf->Cell(15, 6, $agendamento['id'], 1);
            $pdf->Cell(40, 6, $agendamento['cliente_nome'], 1);
            $pdf->Cell(40, 6, $agendamento['consultor_nome'], 1);
            $pdf->Cell(40, 6, $agendamento['servico_nome'], 1);
            $pdf->Cell(30, 6, date('d/m/Y H:i', strtotime($agendamento['data_hora'])), 1);
            $pdf->Cell(25, 6, $agendamento['status'], 1);
            $pdf->Ln();
        }

        // Saída do PDF
        $pdf->Output('agendamentos.pdf', 'D');
    }

} catch(PDOException $e) {
    header('HTTP/1.1 500 Internal Server Error');
    echo "Erro: " . $e->getMessage();
}
?>
