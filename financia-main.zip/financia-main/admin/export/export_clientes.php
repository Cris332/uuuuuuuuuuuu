<?php
require_once '../../config.php';
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['admin_id'])) {
    header('HTTP/1.0 403 Forbidden');
    exit('Acesso negado');
}

// Tipo de exportação (PDF ou CSV)
$type = isset($_GET['type']) ? $_GET['type'] : 'pdf';

try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $query = "SELECT c.*, 
              COUNT(a.id) as total_agendamentos,
              MAX(a.data_hora) as ultimo_agendamento
              FROM clientes c 
              LEFT JOIN agendamentos a ON c.id = a.cliente_id 
              GROUP BY c.id";

    $stmt = $pdo->prepare($query);
    $stmt->execute();
    $clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($type === 'csv') {
        // Configuração do cabeçalho para download do CSV
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="clientes.csv"');

        $output = fopen('php://output', 'w');

        // Cabeçalhos do CSV
        fputcsv($output, ['ID', 'Nome', 'Email', 'Telefone', 'Total Agendamentos', 'Último Agendamento']);

        // Dados
        foreach ($clientes as $cliente) {
            fputcsv($output, [
                $cliente['id'],
                $cliente['nome'],
                $cliente['email'],
                $cliente['telefone'],
                $cliente['total_agendamentos'],
                $cliente['ultimo_agendamento']
            ]);
        }

        fclose($output);
    } else {
        // Gerar PDF usando TCPDF
        require_once('../../lib/tcpdf/tcpdf.php');

        $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
        
        // Configurações do documento
        $pdf->SetCreator('FinanceConsult Pro');
        $pdf->SetAuthor('Administrador');
        $pdf->SetTitle('Relatório de Clientes');

        // Configurações de fonte
        $pdf->SetFont('helvetica', '', 10);

        // Adiciona uma página
        $pdf->AddPage();

        // Título do relatório
        $pdf->SetFont('helvetica', 'B', 16);
        $pdf->Cell(0, 15, 'Relatório de Clientes', 0, true, 'C');
        $pdf->Ln(10);

        // Cabeçalhos da tabela
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(15, 7, 'ID', 1);
        $pdf->Cell(50, 7, 'Nome', 1);
        $pdf->Cell(50, 7, 'Email', 1);
        $pdf->Cell(30, 7, 'Telefone', 1);
        $pdf->Cell(20, 7, 'Total', 1);
        $pdf->Cell(25, 7, 'Último', 1);
        $pdf->Ln();

        // Dados da tabela
        $pdf->SetFont('helvetica', '', 10);
        foreach ($clientes as $cliente) {
            $pdf->Cell(15, 6, $cliente['id'], 1);
            $pdf->Cell(50, 6, $cliente['nome'], 1);
            $pdf->Cell(50, 6, $cliente['email'], 1);
            $pdf->Cell(30, 6, $cliente['telefone'], 1);
            $pdf->Cell(20, 6, $cliente['total_agendamentos'], 1);
            $pdf->Cell(25, 6, $cliente['ultimo_agendamento'] ? date('d/m/Y', strtotime($cliente['ultimo_agendamento'])) : '-', 1);
            $pdf->Ln();
        }

        // Saída do PDF
        $pdf->Output('clientes.pdf', 'D');
    }

} catch(PDOException $e) {
    header('HTTP/1.1 500 Internal Server Error');
    echo "Erro: " . $e->getMessage();
}
?>
