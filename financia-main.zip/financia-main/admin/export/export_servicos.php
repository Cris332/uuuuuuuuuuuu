<?php
require_once '../../config.php';
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['admin_id'])) {
    header('HTTP/1.0 403 Forbidden');
    exit('Acesso negado');
}

// Tipo de exportação (PDF ou CSV)
$type = isset($_GET['type']) ? $_GET['type'] : 'pdf';

try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $query = "SELECT s.*, 
              COUNT(a.id) as total_agendamentos,
              AVG(TIMESTAMPDIFF(MINUTE, a.data_hora, DATE_ADD(a.data_hora, INTERVAL a.duracao MINUTE))) as duracao_media
              FROM servicos s 
              LEFT JOIN agendamentos a ON s.id = a.servico_id 
              GROUP BY s.id";

    $stmt = $pdo->prepare($query);
    $stmt->execute();
    $servicos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($type === 'csv') {
        // Configuração do cabeçalho para download do CSV
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="servicos.csv"');

        $output = fopen('php://output', 'w');

        // Cabeçalhos do CSV
        fputcsv($output, ['ID', 'Nome', 'Descrição', 'Duração (min)', 'Preço', 'Total Agendamentos', 'Status']);

        // Dados
        foreach ($servicos as $servico) {
            fputcsv($output, [
                $servico['id'],
                $servico['nome'],
                $servico['descricao'],
                $servico['duracao'],
                $servico['preco'],
                $servico['total_agendamentos'],
                $servico['status']
            ]);
        }

        fclose($output);
    } else {
        // Gerar PDF usando TCPDF
        require_once('../../lib/tcpdf/tcpdf.php');

        $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
        
        // Configurações do documento
        $pdf->SetCreator('FinanceConsult Pro');
        $pdf->SetAuthor('Administrador');
        $pdf->SetTitle('Relatório de Serviços');

        // Configurações de fonte
        $pdf->SetFont('helvetica', '', 10);

        // Adiciona uma página
        $pdf->AddPage();

        // Título do relatório
        $pdf->SetFont('helvetica', 'B', 16);
        $pdf->Cell(0, 15, 'Relatório de Serviços', 0, true, 'C');
        $pdf->Ln(10);

        // Cabeçalhos da tabela
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(15, 7, 'ID', 1);
        $pdf->Cell(50, 7, 'Nome', 1);
        $pdf->Cell(30, 7, 'Duração', 1);
        $pdf->Cell(25, 7, 'Preço', 1);
        $pdf->Cell(35, 7, 'Total Agend.', 1);
        $pdf->Cell(25, 7, 'Status', 1);
        $pdf->Ln();

        // Dados da tabela
        $pdf->SetFont('helvetica', '', 10);
        foreach ($servicos as $servico) {
            $pdf->Cell(15, 6, $servico['id'], 1);
            $pdf->Cell(50, 6, $servico['nome'], 1);
            $pdf->Cell(30, 6, $servico['duracao'].' min', 1);
            $pdf->Cell(25, 6, 'R$ '.number_format($servico['preco'], 2, ',', '.'), 1);
            $pdf->Cell(35, 6, $servico['total_agendamentos'], 1);
            $pdf->Cell(25, 6, $servico['status'], 1);
            $pdf->Ln();
        }

        // Saída do PDF
        $pdf->Output('servicos.pdf', 'D');
    }

} catch(PDOException $e) {
    header('HTTP/1.1 500 Internal Server Error');
    echo "Erro: " . $e->getMessage();
}
?>
