// Função para mostrar notificações
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;

    // Adicionar ao corpo do documento
    document.body.appendChild(notification);

    // Animar entrada
    setTimeout(() => notification.classList.add('show'), 100);

    // Remover após 3 segundos
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Função para adicionar novo consultor à grade
function adicionarConsultorNaGrade(consultor) {
    const consultantsGrid = document.querySelector('.consultants-grid');
    const card = document.createElement('div');
    card.classList.add('consultant-card');

    // Gerar ID aleatório para a imagem do consultor
    const randomNum = Math.floor(Math.random() * 70) + 1;
    const gender = Math.random() > 0.5 ? 'men' : 'women';

    card.innerHTML = `
        <div class="consultant-header">
            <span class="status-badge">Ativo</span>
            <img src="https://randomuser.me/api/portraits/${gender}/${randomNum}.jpg" alt="${consultor.nome}">
            <h3>${consultor.nome}</h3>
            <p>Consultor Financeiro</p>
        </div>
        
        <div class="consultant-body">
            <div class="consultant-details">
                <div class="detail-row">
                    <i class="fas fa-envelope"></i>
                    <span>${consultor.email}</span>
                </div>
                <div class="detail-row">
                    <i class="fas fa-phone-alt"></i>
                    <span>${consultor.telefone}</span>
                </div>
                <div class="detail-row">
                    <i class="fas fa-clipboard-list"></i>
                    <span>${consultor.agendamentos} agendamentos este mês</span>
                </div>
                <div class="detail-row">
                    <i class="fas fa-star"></i>
                    <span>${consultor.media_avaliacao}/5.0 (${consultor.total_avaliacoes} avaliações)</span>
                </div>
            </div>
            
            <div class="consultant-specialties">
                <h4>Especialidades</h4>
                <div>
                    ${consultor.especialidade.split(',').map(esp =>
        `<span class="specialty-tag">${esp.trim()}</span>`
    ).join('')}
                </div>
            </div>
            
            <div class="consultant-schedule">
                <h4>Disponibilidade</h4>
                <p>${consultor.disponibilidade}</p>
            </div>
        </div>
        
        <div class="consultant-footer">
            <button class="btn-outline edit" data-id="${consultor.id}">
                <i class="fas fa-edit"></i> Editar
            </button>
            <button class="btn-outline view-schedule" data-id="${consultor.id}">
                <i class="fas fa-calendar-alt"></i> Ver Agenda
            </button>
        </div>
    `;

    // Adicionar o novo card no início da grade
    consultantsGrid.insertBefore(card, consultantsGrid.firstChild);

    // Aplicar animação de entrada
    setTimeout(() => card.classList.add('fade-in'), 100);
}

document.addEventListener('DOMContentLoaded', function () {
    // Referência ao modal e botão de adicionar
    const addConsultorBtn = document.querySelector('.btn-primary');
    const modal = document.getElementById('addConsultorModal');
    const closeBtn = document.querySelector('.close-modal');
    const consultorForm = document.getElementById('addConsultorForm');

    // Abrir modal
    addConsultorBtn.addEventListener('click', function () {
        modal.style.display = 'block';
        loadServicos();
    });

    // Fechar modal
    closeBtn.addEventListener('click', function () {
        modal.style.display = 'none';
    });

    // Fechar modal ao clicar fora
    window.addEventListener('click', function (event) {
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    });

    // Carregar serviços disponíveis
    async function loadServicos() {
        try {
            const response = await fetch('../services_data.php');
            const data = await response.json();
            const servicosContainer = document.getElementById('servicos-container');

            if (data.services) {
                servicosContainer.innerHTML = data.services.map(servico => `
                    <div class="checkbox-container">
                        <input type="checkbox" id="servico-${servico.id}" name="servicos[]" value="${servico.id}">
                        <label for="servico-${servico.id}">${servico.nome}</label>
                    </div>
                `).join('');
            }
        } catch (error) {
            console.error('Erro ao carregar serviços:', error);
        }
    }

    // Manipular envio do formulário
    consultorForm.addEventListener('submit', async function (e) {
        e.preventDefault();

        // Coletar dados do formulário
        const formData = new FormData(consultorForm);
        const servicos = Array.from(document.querySelectorAll('input[name="servicos[]"]:checked')).map(cb => cb.value);

        // Criar objeto com dados do consultor
        const consultorData = {
            nome: formData.get('nome'),
            email: formData.get('email'),
            telefone: formData.get('telefone'),
            especialidades: formData.get('especialidades'),
            disponibilidade: formData.get('disponibilidade'),
            servicos: servicos
        };

        try {
            const response = await fetch('api/save_consultor.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(consultorData)
            });

            const result = await response.json(); if (result.success) {
                // Criar e mostrar notificação de sucesso
                showNotification('Consultor adicionado com sucesso!', 'success');

                // Limpar formulário e fechar modal
                modal.style.display = 'none';
                consultorForm.reset();

                // Adicionar novo consultor à grade
                const novoConsultor = {
                    id: result.consultorId,
                    nome: consultorData.nome,
                    email: consultorData.email,
                    telefone: consultorData.telefone,
                    especialidade: consultorData.especialidades,
                    status: 'ativo',
                    agendamentos: 0,
                    media_avaliacao: '0.0',
                    total_avaliacoes: 0,
                    disponibilidade: consultorData.disponibilidade
                };

                adicionarConsultorNaGrade(novoConsultor);
            } else {
                showNotification('Erro ao adicionar consultor: ' + result.error, 'error');
            }
        } catch (error) {
            console.error('Erro ao salvar consultor:', error);
            alert('Erro ao salvar consultor. Por favor, tente novamente.');
        }
    });
});
