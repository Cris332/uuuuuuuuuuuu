document.addEventListener('DOMContentLoaded', function () {
    // Estado da aplicação
    let allClients = [];
    let filteredClients = [];

    // Elementos do DOM
    const clientsGrid = document.querySelector('.clients-grid');
    const searchInput = document.querySelector('.search-box input');
    const sortSelect = document.querySelector('.filters select');

    // Função para carregar clientes
    function loadClients() {
        setLoading(true);

        fetch('api/get_clientes.php')
            .then(async response => {
                const text = await response.text();
                try {
                    const data = JSON.parse(text);
                    if (!response.ok) throw new Error(data.error || 'Erro na requisição');
                    return data;
                } catch (e) {
                    console.error('Resposta do servidor:', text);
                    throw new Error('Erro ao processar resposta do servidor');
                }
            })
            .then(data => {
                if (!data.success) throw new Error(data.error || 'Erro ao carregar clientes');
                if (!Array.isArray(data.clientes)) throw new Error('Formato de dados inválido');

                allClients = data.clientes;
                updateDisplay();
            })
            .catch(error => {
                console.error('Erro:', error);
                showError(error.message);
            })
            .finally(() => {
                setLoading(false);
            });
    }

    // Função para mostrar erro
    function showError(message) {
        clientsGrid.innerHTML = `
            <div class="error-state">
                <i class="fas fa-exclamation-circle"></i>
                <p>Erro ao carregar clientes: ${message}</p>
                <button onclick="window.location.reload()" class="btn-retry">
                    <i class="fas fa-sync-alt"></i> Tentar novamente
                </button>
            </div>
        `;
    }

    // Função para mostrar/ocultar loading
    function setLoading(isLoading) {
        if (isLoading) {
            clientsGrid.innerHTML = `
                <div class="loading-state">
                    <i class="fas fa-spinner fa-spin"></i>
                    <p>Carregando clientes...</p>
                </div>
            `;
        }
    }

    // Função para atualizar a exibição
    function updateDisplay() {
        // Aplicar filtros e ordenação
        const searchTerm = searchInput.value.toLowerCase();
        const sortBy = sortSelect.value;

        filteredClients = allClients.filter(cliente =>
            cliente.nome.toLowerCase().includes(searchTerm) ||
            cliente.email.toLowerCase().includes(searchTerm) ||
            cliente.telefone.includes(searchTerm)
        );

        // Ordenar clientes
        filteredClients.sort((a, b) => {
            switch (sortBy) {
                case 'nome':
                    return a.nome.localeCompare(b.nome);
                case 'data_cadastro':
                    return b.dias_desde_cadastro - a.dias_desde_cadastro;
                case 'agendamentos':
                    return b.total_agendamentos - a.total_agendamentos;
                case 'avaliacao':
                    return b.avaliacao - a.avaliacao;
                default:
                    return 0;
            }
        });

        // Verificar se há clientes
        if (filteredClients.length === 0) {
            clientsGrid.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-users"></i>
                    <p>Nenhum cliente encontrado${searchTerm ? ' com o termo "' + searchTerm + '"' : ''}.</p>
                    ${searchTerm ? '<button onclick="clearSearch()" class="btn-secondary">Limpar busca</button>' : ''}
                </div>
            `;
            return;
        }

        // Renderizar cards
        clientsGrid.innerHTML = filteredClients.map(cliente => `
            <div class="client-card" data-id="${cliente.id}">
                <div class="client-header">
                    <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(cliente.nome)}&background=random" 
                         alt="${cliente.nome}">
                    <h3>${cliente.nome}</h3>
                    <p>Cliente desde ${cliente.data_cadastro}</p>
                </div>
                
                <div class="client-body">
                    <div class="client-details">
                        <div class="detail-row">
                            <i class="fas fa-envelope"></i>
                            <span>${cliente.email || 'Email não cadastrado'}</span>
                        </div>
                        <div class="detail-row">
                            <i class="fas fa-phone-alt"></i>
                            <span>${cliente.telefone || 'Telefone não cadastrado'}</span>
                        </div>
                        <div class="detail-row">
                            <i class="fas fa-calendar-check"></i>
                            <span>${cliente.total_agendamentos} consulta${cliente.total_agendamentos !== 1 ? 's' : ''}</span>
                            ${cliente.ultimo_agendamento ?
                `<small>(Última em ${cliente.ultimo_agendamento})</small>` :
                ''}
                        </div>
                        <div class="detail-row">
                            <i class="fas fa-star"></i>
                            <span>${cliente.avaliacao}/5.0</span>
                            <small>(${cliente.total_avaliacoes} avaliação${cliente.total_avaliacoes !== 1 ? 's' : ''})</small>
                        </div>
                    </div>
                    
                    <div class="client-services">
                        <h4>Serviços Utilizados</h4>
                        <div class="service-tags">
                            ${cliente.servicos_utilizados.length > 0 ?
                cliente.servicos_utilizados
                    .map(servico => `<span class="service-tag">${servico}</span>`)
                    .join('') :
                '<span class="no-services">Nenhum serviço utilizado</span>'
            }
                        </div>
                    </div>
                    
                    <div class="client-actions">
                        <button class="btn-icon view-history" onclick="viewHistory(${cliente.id})" title="Ver histórico">
                            <i class="fas fa-history"></i>
                        </button>
                        <button class="btn-icon schedule-appointment" onclick="scheduleAppointment(${cliente.id})" title="Agendar consulta">
                            <i class="fas fa-calendar-plus"></i>
                        </button>
                        <button class="btn-icon edit-client" onclick="editClient(${cliente.id})" title="Editar cliente">
                            <i class="fas fa-edit"></i>
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
    }

    // Função para limpar busca
    window.clearSearch = function () {
        searchInput.value = '';
        updateDisplay();
    };

    // Funções de ação
    window.viewHistory = function (id) {
        const cliente = allClients.find(c => c.id === id);
        // TODO: Implementar visualização do histórico
        console.log('Ver histórico do cliente:', cliente);
    };

    window.scheduleAppointment = function (id) {
        // Redirecionar para página de agendamento com cliente pré-selecionado
        window.location.href = `agendamentos.html?cliente=${id}`;
    };

    window.editClient = function (id) {
        const cliente = allClients.find(c => c.id === id);
        // TODO: Implementar edição do cliente
        console.log('Editar cliente:', cliente);
    };

    // Event Listeners
    searchInput.addEventListener('input', updateDisplay);
    sortSelect.addEventListener('change', updateDisplay);

    // Inicialização
    loadClients();
});
