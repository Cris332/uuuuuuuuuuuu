// Funções para manipulação das configurações
document.addEventListener('DOMContentLoaded', function () {
    // Inicialização de máscaras
    const cnpjInput = document.getElementById('cnpj');
    const telefoneInput = document.getElementById('telefone');
    const whatsappInput = document.getElementById('whatsapp');

    // Máscaras para campos
    if (cnpjInput) {
        IMask(cnpjInput, {
            mask: '00.000.000/0000-00'
        });
    }

    const phoneMask = {
        mask: '(00) 00000-0000'
    };
    if (telefoneInput) IMask(telefoneInput, phoneMask);
    if (whatsappInput) IMask(whatsappInput, phoneMask);

    // Upload de Logo
    const logoInput = document.getElementById('logo-input');
    const logoPreview = document.getElementById('logo-preview');
    const uploadButton = document.getElementById('upload-logo');

    if (uploadButton) {
        uploadButton.addEventListener('click', () => logoInput.click());
    }

    if (logoInput) {
        logoInput.addEventListener('change', function (e) {
            if (e.target.files && e.target.files[0]) {
                const reader = new FileReader();
                reader.onload = function (e) {
                    logoPreview.src = e.target.result;
                };
                reader.readAsDataURL(e.target.files[0]);
            }
        });
    }

    // Preview de cores
    const corPrimaria = document.getElementById('cor-primaria');
    const corSecundaria = document.getElementById('cor-secundaria');
    const previewHeader = document.getElementById('preview-header');
    const previewButtons = document.getElementById('preview-buttons');

    function updateColorPreviews() {
        if (previewHeader) {
            previewHeader.style.backgroundColor = corPrimaria.value;
        }
        if (previewButtons) {
            previewButtons.style.backgroundColor = corSecundaria.value;
        }
    }

    if (corPrimaria) {
        corPrimaria.addEventListener('input', updateColorPreviews);
    }
    if (corSecundaria) {
        corSecundaria.addEventListener('input', updateColorPreviews);
    }

    // Salvar configurações
    const saveConfigBtn = document.getElementById('save-config');
    if (saveConfigBtn) {
        saveConfigBtn.addEventListener('click', saveConfiguracoes);
    }

    // Restaurar padrões
    const resetConfigBtn = document.getElementById('reset-config');
    if (resetConfigBtn) {
        resetConfigBtn.addEventListener('click', confirmResetConfig);
    }

    // Backup manual
    const backupManualBtn = document.getElementById('backup-manual');
    if (backupManualBtn) {
        backupManualBtn.addEventListener('click', realizarBackupManual);
    }

    // Restaurar backup
    const restoreBackupBtn = document.getElementById('restore-backup');
    if (restoreBackupBtn) {
        restoreBackupBtn.addEventListener('click', confirmRestoreBackup);
    }

    // Carregar configurações existentes
    carregarConfiguracoes();
});

// Função para salvar as configurações
async function saveConfiguracoes() {
    try {
        const formData = new FormData();

        // Validação dos campos obrigatórios
        const requiredFields = ['nome-empresa', 'cnpj', 'telefone', 'email'];
        for (const fieldId of requiredFields) {
            const field = document.getElementById(fieldId);
            if (!field.value.trim()) {
                throw new Error(`O campo ${field.previousElementSibling.textContent} é obrigatório.`);
            }
            formData.append(field.name, field.value.trim());
        }

        // Dados da empresa
        const empresaForm = document.getElementById('empresa-form');
        const personalizacaoForm = document.getElementById('personalizacao-form');
        const socialForm = document.getElementById('social-form');
        const notificacoesForm = document.getElementById('notifications-form');

        // Adiciona dados do formulário da empresa
        formData.append('nome_empresa', document.getElementById('nome-empresa').value);
        formData.append('cnpj', document.getElementById('cnpj').value);
        formData.append('telefone', document.getElementById('telefone').value);
        formData.append('email', document.getElementById('email').value);
        formData.append('endereco', document.getElementById('endereco').value);
        formData.append('whatsapp', document.getElementById('whatsapp').value);
        formData.append('horario_funcionamento', document.getElementById('horario').value);

        // Logo
        const logoInput = document.getElementById('logo-input');
        if (logoInput.files[0]) {
            const file = logoInput.files[0];
            // Validação do tamanho do arquivo (máx 2MB)
            if (file.size > 2 * 1024 * 1024) {
                throw new Error('A imagem deve ter no máximo 2MB.');
            }
            // Validação do tipo do arquivo
            if (!['image/jpeg', 'image/png', 'image/gif'].includes(file.type)) {
                throw new Error('Formato de imagem não suportado. Use JPG, PNG ou GIF.');
            }
            formData.append('logo', file);
        }

        // Cores
        const corPrimaria = document.getElementById('cor-primaria').value;
        const corSecundaria = document.getElementById('cor-secundaria').value;
        formData.append('cor_primaria', corPrimaria);
        formData.append('cor_secundaria', corSecundaria);

        // Redes sociais
        const socialInputs = ['facebook', 'instagram', 'linkedin'];
        for (const social of socialInputs) {
            const value = document.getElementById(social).value;
            if (value && !isValidUrl(value)) {
                throw new Error(`URL inválida para ${social}`);
            }
            formData.append(`${social}_url`, value);
        }

        // Notificações
        const notificacoes = {};
        const checkboxes = notificacoesForm.querySelectorAll('input[type="checkbox"]');
        checkboxes.forEach(checkbox => {
            notificacoes[checkbox.name] = checkbox.checked;
        });
        formData.append('notificacoes', JSON.stringify(notificacoes));        // Valida os dados antes de enviar
        if (!validarDados(formData)) {
            return;
        }

        // Mostra indicador de progresso
        const restaurarProgresso = mostrarProgresso('Salvando configurações...');

        try {
            const response = await fetch('api/save_config.php', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (data.success) {
                showNotification('Configurações salvas com sucesso!', 'success');

                // Aplica as configurações visualmente
                aplicarConfiguracoes(data.data);

                // Atualiza o preview das cores
                updateColorPreviews();

                // Salva no localStorage para persistência
                localStorage.setItem('configuracoes', JSON.stringify(data.data));
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            showNotification('Erro ao salvar configurações: ' + error.message, 'error');
        } finally {
            // Restaura o botão ao estado original
            restaurarProgresso();
        }
    } catch (error) {
        showNotification('Erro ao salvar configurações: ' + error.message, 'error');
    }
}

// Função para carregar configurações existentes
async function carregarConfiguracoes() {
    try {
        const response = await fetch('api/get_config.php');
        const data = await response.json();

        if (data.success) {
            // Preenche os campos com os dados
            document.getElementById('nome-empresa').value = data.config.nome_empresa;
            document.getElementById('cnpj').value = data.config.cnpj;
            document.getElementById('telefone').value = data.config.telefone;
            document.getElementById('email').value = data.config.email;
            document.getElementById('endereco').value = data.config.endereco;
            document.getElementById('whatsapp').value = data.config.whatsapp;

            // Logo
            if (data.config.logo_url) {
                document.getElementById('logo-preview').src = data.config.logo_url;
            }

            // Cores
            document.getElementById('cor-primaria').value = data.config.cor_primaria;
            document.getElementById('cor-secundaria').value = data.config.cor_secundaria;

            // Redes sociais
            document.getElementById('facebook').value = data.config.facebook_url;
            document.getElementById('instagram').value = data.config.instagram_url;
            document.getElementById('linkedin').value = data.config.linkedin_url;

            // Atualiza previews
            updateColorPreviews();
        }
    } catch (error) {
        showNotification('Erro ao carregar configurações: ' + error.message, 'error');
    }
}

// Função para confirmar reset das configurações
function confirmResetConfig() {
    if (confirm('Tem certeza que deseja restaurar todas as configurações para os valores padrão? Esta ação não pode ser desfeita.')) {
        resetConfig();
    }
}

// Função para resetar configurações
async function resetConfig() {
    try {
        const response = await fetch('api/reset_config.php', {
            method: 'POST'
        });
        const data = await response.json();

        if (data.success) {
            showNotification('Configurações restauradas com sucesso!', 'success');
            carregarConfiguracoes(); // Recarrega as configurações padrão
        } else {
            throw new Error(data.message);
        }
    } catch (error) {
        showNotification('Erro ao restaurar configurações: ' + error.message, 'error');
    }
}

// Função para realizar backup manual
async function realizarBackupManual() {
    try {
        const response = await fetch('api/backup.php', {
            method: 'POST'
        });
        const blob = await response.blob();

        // Cria link para download
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'backup_' + new Date().toISOString().slice(0, 10) + '.sql';
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();

        showNotification('Backup realizado com sucesso!', 'success');
    } catch (error) {
        showNotification('Erro ao realizar backup: ' + error.message, 'error');
    }
}

// Função para confirmar restauração de backup
function confirmRestoreBackup() {
    if (confirm('Tem certeza que deseja restaurar um backup? Os dados atuais serão substituídos.')) {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.sql';
        input.onchange = e => {
            const file = e.target.files[0];
            restaurarBackup(file);
        };
        input.click();
    }
}

// Função para restaurar backup
async function restaurarBackup(file) {
    try {
        const formData = new FormData();
        formData.append('backup_file', file);

        const response = await fetch('api/restore_backup.php', {
            method: 'POST',
            body: formData
        });
        const data = await response.json();

        if (data.success) {
            showNotification('Backup restaurado com sucesso!', 'success');
            setTimeout(() => window.location.reload(), 2000);
        } else {
            throw new Error(data.message);
        }
    } catch (error) {
        showNotification('Erro ao restaurar backup: ' + error.message, 'error');
    }
}

// Função para mostrar notificações
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        ${message}
    `;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.classList.add('fade-out');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Função para validar URLs
function isValidUrl(string) {
    try {
        new URL(string);
        return true;
    } catch (_) {
        return false;
    }
}

// Função para validar CNPJ
function validarCNPJ(cnpj) {
    cnpj = cnpj.replace(/[^\d]+/g, '');
    if (cnpj.length !== 14) return false;

    // Elimina CNPJs invalidos conhecidos
    if (/^(\d)\1+$/.test(cnpj)) return false;

    // Valida DVs
    let tamanho = cnpj.length - 2;
    let numeros = cnpj.substring(0, tamanho);
    const digitos = cnpj.substring(tamanho);
    let soma = 0;
    let pos = tamanho - 7;

    for (let i = tamanho; i >= 1; i--) {
        soma += numeros.charAt(tamanho - i) * pos--;
        if (pos < 2) pos = 9;
    }

    let resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
    if (resultado !== parseInt(digitos.charAt(0))) return false;

    tamanho = tamanho + 1;
    numeros = cnpj.substring(0, tamanho);
    soma = 0;
    pos = tamanho - 7;

    for (let i = tamanho; i >= 1; i--) {
        soma += numeros.charAt(tamanho - i) * pos--;
        if (pos < 2) pos = 9;
    }

    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
    return resultado === parseInt(digitos.charAt(1));
}

// Função para validar e-mail
function validarEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email.toLowerCase());
}

// Função para validar telefone
function validarTelefone(telefone) {
    const numero = telefone.replace(/\D/g, '');
    return numero.length >= 10 && numero.length <= 11;
}

// Função para aplicar máscara ao CNPJ
function mascaraCNPJ(cnpj) {
    return cnpj
        .replace(/\D/g, '')
        .replace(/(\d{2})(\d)/, '$1.$2')
        .replace(/(\d{3})(\d)/, '$1.$2')
        .replace(/(\d{3})(\d)/, '$1/$2')
        .replace(/(\d{4})(\d)/, '$1-$2')
        .replace(/(-\d{2})\d+?$/, '$1');
}

// Função para aplicar máscara ao telefone
function mascaraTelefone(telefone) {
    const numero = telefone.replace(/\D/g, '');
    if (numero.length === 11) {
        return numero.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
    }
    return numero.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
}

// Função para mostrar feedback visual do progresso
function mostrarProgresso(mensagem) {
    const saveBtn = document.getElementById('save-config');
    const originalText = saveBtn.innerHTML;

    saveBtn.innerHTML = `<i class="fas fa-spinner fa-spin"></i> ${mensagem}`;
    saveBtn.disabled = true;

    return () => {
        saveBtn.innerHTML = originalText;
        saveBtn.disabled = false;
    };
}

// Função para aplicar as configurações visualmente
function aplicarConfiguracoes(config) {
    // Atualiza as cores do tema
    document.documentElement.style.setProperty('--primary-color', config.cor_primaria);
    document.documentElement.style.setProperty('--secondary-color', config.cor_secundaria);

    // Atualiza a logo se houver
    if (config.logo_url) {
        const logos = document.querySelectorAll('.logo-icon img');
        logos.forEach(logo => {
            logo.src = config.logo_url;
        });
    }

    // Atualiza informações do rodapé
    const footerContacts = document.querySelectorAll('.footer-contact p');
    footerContacts.forEach(contact => {
        if (contact.textContent.includes('@')) {
            contact.textContent = config.email;
        } else if (contact.textContent.includes('(')) {
            contact.textContent = config.telefone;
        }
    });
}

// Função para validar os dados antes de enviar
function validarDados(formData) {
    const email = formData.get('email');
    const cnpj = formData.get('cnpj');
    const telefone = formData.get('telefone');

    if (!validarEmail(email)) {
        throw new Error('E-mail inválido');
    }

    if (!validarCNPJ(cnpj)) {
        throw new Error('CNPJ inválido');
    }

    if (!validarTelefone(telefone)) {
        throw new Error('Telefone inválido');
    }

    return true;
}
