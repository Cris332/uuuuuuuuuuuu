document.addEventListener('DOMContentLoaded', function () {
    // Estado da aplicação
    let allConsultants = [];
    let filteredConsultants = [];

    // Elementos do DOM
    const consultantsGrid = document.querySelector('.consultants-grid');
    const statusSelect = document.querySelector('.filters select:nth-child(1)');
    const serviceSelect = document.querySelector('.filters select:nth-child(2)');
    const searchInput = document.querySelector('.search-box input');

    // Função para carregar consultores
    function loadConsultants() {
        setLoading(true);

        // Usar o caminho correto para o arquivo PHP
        fetch('../api/get_consultores.php')
            .then(async response => {
                const text = await response.text();
                try {
                    const data = JSON.parse(text);
                    if (!response.ok) throw new Error(data.error || 'Erro na requisição');
                    return data;
                } catch (e) {
                    console.error('Resposta do servidor:', text);
                    throw new Error('Erro ao processar resposta do servidor');
                }
            })
            .then(data => {
                if (!data.success) throw new Error(data.error || 'Erro ao carregar consultores');
                if (!Array.isArray(data.consultores)) throw new Error('Formato de dados inválido');

                allConsultants = data.consultores;
                updateDisplay();
            })
            .catch(error => {
                console.error('Erro:', error);
                showError(error.message);
            })
            .finally(() => {
                setLoading(false);
            });
    }

    // Função para mostrar erro
    function showError(message) {
        consultantsGrid.innerHTML = `
            <div class="error-state">
                <i class="fas fa-exclamation-circle"></i>
                <p>Erro ao carregar consultores: ${message}</p>
                <button onclick="window.location.reload()" class="btn-retry">
                    <i class="fas fa-sync-alt"></i> Tentar novamente
                </button>
            </div>
        `;
    }

    // Função para mostrar/ocultar loading
    function setLoading(isLoading) {
        if (isLoading) {
            consultantsGrid.innerHTML = `
                <div class="loading-state">
                    <i class="fas fa-spinner fa-spin"></i>
                    <p>Carregando consultores...</p>
                </div>
            `;
        }
    }

    // Função para atualizar a exibição
    function updateDisplay() {
        // Aplicar filtros
        const searchTerm = searchInput.value.toLowerCase();
        const selectedStatus = statusSelect.value;
        const selectedService = serviceSelect.value;

        filteredConsultants = allConsultants.filter(consultor => {
            // Filtro de busca
            const matchesSearch =
                consultor.nome.toLowerCase().includes(searchTerm) ||
                (consultor.email && consultor.email.toLowerCase().includes(searchTerm)) ||
                (consultor.especialidades && consultor.especialidades.toLowerCase().includes(searchTerm));

            // Filtro de status
            const matchesStatus =
                selectedStatus === 'Todos os Status' ||
                consultor.status.toLowerCase() === selectedStatus.toLowerCase();

            // Filtro de serviço
            const matchesService =
                selectedService === 'Todos os Serviços' ||
                (consultor.servicos && Object.values(consultor.servicos).includes(selectedService));

            return matchesSearch && matchesStatus && matchesService;
        });

        // Verificar se há consultores
        if (filteredConsultants.length === 0) {
            consultantsGrid.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-user-tie"></i>
                    <p>Nenhum consultor encontrado com os filtros selecionados.</p>
                    ${searchTerm || selectedStatus !== 'Todos os Status' || selectedService !== 'Todos os Serviços'
                    ? '<button onclick="clearFilters()" class="btn-secondary">Limpar filtros</button>'
                    : ''}
                </div>
            `;
            return;
        }

        // Renderizar cards
        consultantsGrid.innerHTML = filteredConsultants.map(consultor => `
            <div class="consultant-card" data-id="${consultor.id}">
                <div class="consultant-header">
                    <span class="status-badge ${consultor.status.toLowerCase()}">
                        ${consultor.status}
                    </span>
                    <img src="https://randomuser.me/api/portraits/${consultor.id % 2 ? 'men' : 'women'}/${(consultor.id * 123) % 70 + 1}.jpg" 
                         alt="${consultor.nome}">
                    <h3>${consultor.nome}</h3>
                    <p>${consultor.especialidades ? consultor.especialidades.split(',')[0] : 'Consultor Financeiro'}</p>
                </div>
                
                <div class="consultant-body">
                    <div class="consultant-details">
                        <div class="detail-row">
                            <i class="fas fa-envelope"></i>
                            <span>${consultor.email || 'Email não cadastrado'}</span>
                        </div>
                        <div class="detail-row">
                            <i class="fas fa-phone-alt"></i>
                            <span>${consultor.telefone || 'Telefone não cadastrado'}</span>
                        </div>
                        <div class="detail-row">
                            <i class="fas fa-clipboard-list"></i>
                            <span>${consultor.total_agendamentos || 0} agendamentos este mês</span>
                        </div>
                        <div class="detail-row">
                            <i class="fas fa-star"></i>
                            <span>${consultor.avaliacao || '0.0'}/5.0 (${consultor.total_avaliacoes || 0} avaliações)</span>
                        </div>
                    </div>
                    
                    <div class="consultant-specialties">
                        <h4>Especialidades</h4>
                        <div>
                            ${consultor.servicos ? Object.values(consultor.servicos)
                .map(servico => `<span class="specialty-tag">${servico}</span>`)
                .join('') : '<span class="specialty-tag">Sem especialidades cadastradas</span>'}
                        </div>
                    </div>
                    
                    <div class="consultant-actions">
                        <button class="btn-icon edit-consultant" onclick="editConsultant(${consultor.id})" title="Editar consultor">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn-icon view-schedule" onclick="viewSchedule(${consultor.id})" title="Ver agenda">
                            <i class="fas fa-calendar-alt"></i>
                        </button>
                        <button class="btn-icon toggle-status" 
                                onclick="toggleStatus(${consultor.id}, '${consultor.status}')"
                                title="${consultor.status === 'ativo' ? 'Desativar' : 'Ativar'} consultor">
                            <i class="fas fa-toggle-${consultor.status === 'ativo' ? 'on' : 'off'}"></i>
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
    }

    // Função para limpar filtros
    window.clearFilters = function () {
        searchInput.value = '';
        statusSelect.value = 'Todos os Status';
        serviceSelect.value = 'Todos os Serviços';
        updateDisplay();
    };

    // Funções de ação
    window.editConsultant = function (id) {
        const consultor = allConsultants.find(c => c.id === id);
        // TODO: Implementar modal de edição
        console.log('Editar consultor:', consultor);
    };

    window.viewSchedule = function (id) {
        window.location.href = `calendario.html?consultor=${id}`;
    };

    window.toggleStatus = function (id, currentStatus) {
        const newStatus = currentStatus === 'ativo' ? 'inativo' : 'ativo';

        if (confirm(`Deseja ${newStatus === 'ativo' ? 'ativar' : 'desativar'} este consultor?`)) {
            setLoading(true);

            fetch('../api/update_status.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    consultor_id: id,
                    status: newStatus
                })
            })
                .then(response => response.json())
                .then(data => {
                    if (!data.success) throw new Error(data.error || 'Erro ao atualizar status');
                    loadConsultants();  // Recarregar lista
                })
                .catch(error => {
                    console.error('Erro:', error);
                    alert('Erro ao atualizar status do consultor: ' + error.message);
                })
                .finally(() => {
                    setLoading(false);
                });
        }
    };

    // Event Listeners
    statusSelect.addEventListener('change', updateDisplay);
    serviceSelect.addEventListener('change', updateDisplay);
    searchInput.addEventListener('input', updateDisplay);

    // Carregar serviços no filtro
    function loadServices() {
        fetch('../services_data.php')
            .then(response => response.json())
            .then(data => {
                if (data.success && data.servicos) {
                    serviceSelect.innerHTML = '<option>Todos os Serviços</option>' +
                        data.servicos
                            .map(servico => `<option>${servico.nome}</option>`)
                            .join('');
                }
            })
            .catch(error => console.error('Erro ao carregar serviços:', error));
    }

    // Inicialização
    loadServices();
    loadConsultants();
});
