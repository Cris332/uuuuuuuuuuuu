// Funções de exportação
function exportReport(type, reportType) {
    // Obtém os filtros ativos
    const dateStart = document.getElementById('date-start')?.value || '';
    const dateEnd = document.getElementById('date-end')?.value || '';
    const status = document.getElementById('status-filter')?.value || '';

    // Constrói a URL com os parâmetros
    let url = `export/export_${reportType}.php?type=${type}`;
    if (dateStart) url += `&date_start=${dateStart}`;
    if (dateEnd) url += `&date_end=${dateEnd}`;
    if (status) url += `&status=${status}`;

    // Abre a URL em uma nova aba
    window.open(url, '_blank');
}

// Adiciona os listeners aos botões de exportação
document.addEventListener('DOMContentLoaded', function () {
    // Botões de exportação de agendamentos
    const agendamentosExportPDF = document.getElementById('export-agendamentos-pdf');
    const agendamentosExportCSV = document.getElementById('export-agendamentos-csv');
    if (agendamentosExportPDF) {
        agendamentosExportPDF.addEventListener('click', () => exportReport('pdf', 'agendamentos'));
    }
    if (agendamentosExportCSV) {
        agendamentosExportCSV.addEventListener('click', () => exportReport('csv', 'agendamentos'));
    }

    // Botões de exportação de clientes
    const clientesExportPDF = document.getElementById('export-clientes-pdf');
    const clientesExportCSV = document.getElementById('export-clientes-csv');
    if (clientesExportPDF) {
        clientesExportPDF.addEventListener('click', () => exportReport('pdf', 'clientes'));
    }
    if (clientesExportCSV) {
        clientesExportCSV.addEventListener('click', () => exportReport('csv', 'clientes'));
    }

    // Botões de exportação de serviços
    const servicosExportPDF = document.getElementById('export-servicos-pdf');
    const servicosExportCSV = document.getElementById('export-servicos-csv');
    if (servicosExportPDF) {
        servicosExportPDF.addEventListener('click', () => exportReport('pdf', 'servicos'));
    }
    if (servicosExportCSV) {
        servicosExportCSV.addEventListener('click', () => exportReport('csv', 'servicos'));
    }
});
