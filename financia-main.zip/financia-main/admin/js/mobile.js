// Mobile Responsive JavaScript for Admin Panel

document.addEventListener('DOMContentLoaded', function() {
    // Mobile Menu Functionality
    setupMobileMenu();
    
    // Responsive Table Functionality
    setupResponsiveTables();
    
    // Mobile Pagination Functionality
    setupMobilePagination();
    
    // Handle window resize events
    handleWindowResize();
});

/**
 * Setup mobile menu functionality
 */
function setupMobileMenu() {
    // Create mobile menu toggle button
    createMobileMenuToggle();
    
    // Create mobile menu overlay
    createMobileMenuOverlay();
    
    // Add hamburger menu to sidebar header
    addHamburgerMenu();
    
    // Setup event listeners for mobile menu
    setupMobileMenuEventListeners();
}

/**
 * Create mobile menu toggle button
 */
function createMobileMenuToggle() {
    const toggleButton = document.createElement('button');
    toggleButton.className = 'mobile-sidebar-toggle';
    toggleButton.innerHTML = '<i class="fas fa-bars"></i>';
    toggleButton.setAttribute('aria-label', 'Toggle Menu');
    document.body.appendChild(toggleButton);
}

/**
 * Create mobile menu overlay
 */
function createMobileMenuOverlay() {
    const overlay = document.createElement('div');
    overlay.className = 'mobile-menu-overlay';
    document.body.appendChild(overlay);
}

/**
 * Add hamburger menu to sidebar header
 */
function addHamburgerMenu() {
    const sidebarHeader = document.querySelector('.sidebar-header');
    
    if (sidebarHeader) {
        const hamburgerMenu = document.createElement('div');
        hamburgerMenu.className = 'hamburger-menu';
        hamburgerMenu.innerHTML = '<span></span><span></span><span></span>';
        sidebarHeader.appendChild(hamburgerMenu);
    }
}

/**
 * Setup event listeners for mobile menu
 */
function setupMobileMenuEventListeners() {
    const toggleButton = document.querySelector('.mobile-sidebar-toggle');
    const hamburgerMenu = document.querySelector('.hamburger-menu');
    const overlay = document.querySelector('.mobile-menu-overlay');
    const sidebar = document.querySelector('.sidebar');
    
    // Toggle button click event
    if (toggleButton && sidebar) {
        toggleButton.addEventListener('click', function() {
            sidebar.classList.toggle('mobile-expanded');
            overlay.classList.toggle('active');
            document.body.style.overflow = sidebar.classList.contains('mobile-expanded') ? 'hidden' : '';
        });
    }
    
    // Hamburger menu click event
    if (hamburgerMenu && sidebar) {
        hamburgerMenu.addEventListener('click', function() {
            sidebar.classList.toggle('mobile-expanded');
            overlay.classList.toggle('active');
            document.body.style.overflow = sidebar.classList.contains('mobile-expanded') ? 'hidden' : '';
        });
    }
    
    // Overlay click event
    if (overlay && sidebar) {
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('mobile-expanded');
            overlay.classList.remove('active');
            document.body.style.overflow = '';
        });
    }
    
    // Menu item click event (close menu when item is clicked)
    const menuItems = document.querySelectorAll('.sidebar-nav a');
    menuItems.forEach(item => {
        item.addEventListener('click', function() {
            if (window.innerWidth <= 992) {
                sidebar.classList.remove('mobile-expanded');
                overlay.classList.remove('active');
                document.body.style.overflow = '';
            }
        });
    });
}

/**
 * Setup responsive tables
 */
function setupResponsiveTables() {
    // Add data-label attributes to table cells based on headers
    const tables = document.querySelectorAll('.appointments-table');
    
    tables.forEach(table => {
        const headerCells = table.querySelectorAll('.table-header .table-cell');
        const rows = table.querySelectorAll('.table-row');
        
        rows.forEach(row => {
            const cells = row.querySelectorAll('.table-cell');
            
            cells.forEach((cell, index) => {
                if (headerCells[index] && !cell.hasAttribute('data-label')) {
                    const headerText = headerCells[index].textContent.trim();
                    cell.setAttribute('data-label', headerText);
                }
            });
        });
    });
}

/**
 * Handle window resize events
 */
function handleWindowResize() {
    window.addEventListener('resize', function() {
        const sidebar = document.querySelector('.sidebar');
        const overlay = document.querySelector('.mobile-menu-overlay');
        
        // Reset mobile menu state on window resize to desktop
        if (window.innerWidth > 992 && sidebar && overlay) {
            sidebar.classList.remove('mobile-expanded');
            overlay.classList.remove('active');
            document.body.style.overflow = '';
        }
        
        // Update mobile pagination visibility based on screen size
        updateMobilePaginationVisibility();
    });
}

/**
 * Setup mobile pagination for better navigation on small screens
 */
function setupMobilePagination() {
    // Find all pagination containers
    const paginationContainers = document.querySelectorAll('.pagination-container, .pagination');
    
    paginationContainers.forEach(container => {
        // Check if mobile navigation already exists
        if (container.querySelector('.mobile-pagination-nav')) {
            return;
        }
        
        // Get pagination controls
        const controls = container.querySelector('.pagination-controls');
        if (!controls) return;
        
        // Create mobile navigation container
        const mobileNav = document.createElement('div');
        mobileNav.className = 'mobile-pagination-nav';
        
        // Create previous page button
        const prevButton = document.createElement('button');
        prevButton.innerHTML = '<i class="fas fa-arrow-left"></i> Anterior';
        prevButton.className = 'prev-page';
        
        // Create next page button
        const nextButton = document.createElement('button');
        nextButton.innerHTML = 'Próxima <i class="fas fa-arrow-right"></i>';
        nextButton.className = 'next-page';
        
        // Add buttons to mobile navigation
        mobileNav.appendChild(prevButton);
        mobileNav.appendChild(nextButton);
        
        // Add mobile navigation to container
        container.appendChild(mobileNav);
        
        // Setup event listeners for mobile pagination
        setupMobilePaginationEvents(container, prevButton, nextButton);
    });
    
    // Initial visibility update
    updateMobilePaginationVisibility();
}

/**
 * Setup event listeners for mobile pagination buttons
 */
function setupMobilePaginationEvents(container, prevButton, nextButton) {
    // Get all page buttons
    const pageButtons = container.querySelectorAll('.pagination-btn:not(:first-child):not(:last-child), .pagination-controls .btn-outline:not(:first-child):not(:last-child)');
    const prevPageBtn = container.querySelector('.pagination-btn:first-child, .pagination-controls .btn-outline:first-child');
    const nextPageBtn = container.querySelector('.pagination-btn:last-child, .pagination-controls .btn-outline:last-child');
    
    // Update button states
    updateMobilePaginationButtonStates(prevButton, nextButton, prevPageBtn, nextPageBtn);
    
    // Previous button click event
    prevButton.addEventListener('click', function() {
        if (prevPageBtn && !prevPageBtn.disabled) {
            prevPageBtn.click();
        }
    });
    
    // Next button click event
    nextButton.addEventListener('click', function() {
        if (nextPageBtn && !nextPageBtn.disabled) {
            nextPageBtn.click();
        }
    });
    
    // Update mobile buttons when regular pagination buttons are clicked
    pageButtons.forEach(button => {
        button.addEventListener('click', function() {
            updateMobilePaginationButtonStates(prevButton, nextButton, prevPageBtn, nextPageBtn);
        });
    });
}

/**
 * Update mobile pagination button states based on regular pagination
 */
function updateMobilePaginationButtonStates(prevButton, nextButton, prevPageBtn, nextPageBtn) {
    // Update previous button state
    if (prevPageBtn) {
        prevButton.disabled = prevPageBtn.disabled;
    }
    
    // Update next button state
    if (nextPageBtn) {
        nextButton.disabled = nextPageBtn.disabled;
    }
}

/**
 * Update mobile pagination visibility based on screen size
 */
function updateMobilePaginationVisibility() {
    const mobileNavs = document.querySelectorAll('.mobile-pagination-nav');
    
    mobileNavs.forEach(nav => {
        if (window.innerWidth <= 576) {
            nav.style.display = 'flex';
        } else {
            nav.style.display = 'none';
        }
    });
}