// Gerenciamento de Configurações

document.addEventListener('DOMContentLoaded', function () {
    // Navegação por Tabs
    const tabs = document.querySelectorAll('.settings-tabs a');
    const sections = document.querySelectorAll('.settings-section .card');

    // Função para mostrar uma seção
    function showSection(targetId) {
        sections.forEach(section => {
            if (section.id === targetId || (!targetId && section === sections[0])) {
                section.style.display = 'block';
            } else {
                section.style.display = 'none';
            }
        });
    }

    // Inicialização: mostrar a primeira seção
    showSection();

    // Adicionar eventos de clique nas tabs
    tabs.forEach(tab => {
        tab.addEventListener('click', (e) => {
            e.preventDefault();

            // Remover classe active de todas as tabs
            tabs.forEach(t => t.classList.remove('active'));

            // Adicionar classe active na tab clicada
            tab.classList.add('active');

            // Mostrar a seção correspondente
            const targetId = tab.getAttribute('href').substring(1);
            showSection(targetId);
        });
    });

    // Botões de Ação
    const saveConfigBtn = document.getElementById('save-config');
    const resetConfigBtn = document.getElementById('reset-config');

    if (saveConfigBtn) {
        saveConfigBtn.addEventListener('click', async () => {
            try {
                // TODO: Implementar salvamento das configurações
                alert('Configurações salvas com sucesso!');
            } catch (error) {
                console.error('Erro ao salvar configurações:', error);
                alert('Erro ao salvar configurações. Tente novamente.');
            }
        });
    }

    if (resetConfigBtn) {
        resetConfigBtn.addEventListener('click', () => {
            if (confirm('Tem certeza que deseja restaurar todas as configurações para os valores padrão?')) {
                // TODO: Implementar restauração das configurações
                alert('Configurações restauradas com sucesso!');
            }
        });
    }
});
