document.addEventListener('DOMContentLoaded', function() {
    const bottomNavLinks = document.querySelectorAll('.bottom-nav a');
    // Pega o nome do arquivo da URL atual (ex: 'dashboard.html')
    const currentPageFile = window.location.pathname.split('/').pop();

    if (bottomNavLinks.length > 0 && currentPageFile) {
        bottomNavLinks.forEach(link => {
            const linkFile = link.getAttribute('href').split('/').pop();
            // Remove a classe 'active' de todos os links primeiro
            link.classList.remove('active');
            // Adiciona a classe 'active' se o href do link corresponder à página atual
            if (linkFile === currentPageFile) {
                link.classList.add('active');
            }
        });
    } else if (bottomNavLinks.length > 0 && (window.location.pathname.endsWith('/') || currentPageFile === '')) {
        // Caso especial para a raiz do site (ex: 'admin/' ou 'admin/index.html')
        // Tenta ativar 'dashboard.html' ou 'index.html' se for a raiz
        bottomNavLinks.forEach(link => {
            const linkFile = link.getAttribute('href').split('/').pop();
            link.classList.remove('active');
            if (linkFile === 'dashboard.html' || linkFile === 'index.html') {
                link.classList.add('active');
            }
        });
        // Se, após o loop, nenhum link 'dashboard.html' ou 'index.html' foi ativado (e ainda estamos na raiz),
        // e o primeiro link não tem href vazio, ative o primeiro link como fallback.
        // Isso é uma suposição, pode precisar de ajuste se a página raiz não for dashboard/index.
        let oneActive = false;
        bottomNavLinks.forEach(link => { if(link.classList.contains('active')) oneActive = true; });
        if (!oneActive && bottomNavLinks[0] && bottomNavLinks[0].getAttribute('href') !== '') {
            // Ativa o primeiro link se nenhum outro foi ativado e estamos na página raiz
            // e o primeiro link tem um href válido.
            const firstLinkFile = bottomNavLinks[0].getAttribute('href').split('/').pop();
            if (currentPageFile === '' || window.location.pathname.endsWith('/')) {
                 // Se for realmente a raiz, e o primeiro link for dashboard.html, ative-o
                 // Ou se for qualquer outro primeiro link, ative-o como fallback para a raiz
                 if (firstLinkFile === 'dashboard.html' || firstLinkFile === 'index.html' || currentPageFile === '') {
                    bottomNavLinks[0].classList.add('active');
                 }
            }
        }
    }
});
