document.addEventListener('DOMContentLoaded', function() {
    console.log('services.js: Script carregado com sucesso');
    let statusFilter = '';
    let searchQuery = '';

    // Elementos do DOM
    const servicesGrid = document.querySelector('.services-grid');
    const statusSelect = document.querySelector('.filters select');
    const searchInput = document.querySelector('.search-box input');
    const newServiceBtn = document.querySelector('.actions .btn-primary');

    // Verificar se os elementos existem
    if (!servicesGrid || !statusSelect || !searchInput || !newServiceBtn) {
        console.error('services.js: Um ou mais elementos do DOM não foram encontrados');
        alert('Erro: Estrutura da página inválida. Verifique o console.');
        return;
    }

    // Inicializar
    function initServices() {
        console.log('services.js: Inicializando...');
        loadData();
        setupEventListeners();
    }

    // Carregar dados
    function loadData() {
        const params = new URLSearchParams({
            status: statusFilter,
            search: searchQuery
        });
        console.log('services.js: Carregando dados com parâmetros:', params.toString());

        fetch(`../services_data.php?${params.toString()}`)
            .then(response => {
                console.log('services.js: Status da requisição:', response.status);
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('services.js: Dados recebidos:', data);
                if (data.error) {
                    console.error('Erro do servidor:', data.error);
                    alert('Erro ao carregar dados: ' + data.error);
                    return;
                }
                updateServicesGrid(data.services);
            })
            .catch(error => {
                console.error('services.js: Erro ao carregar dados:', error);
                alert('Erro ao carregar dados: ' + error.message);
            });
    }

    // Atualizar grade de serviços
    function updateServicesGrid(services) {
        console.log('services.js: Atualizando grade com:', services);
        servicesGrid.innerHTML = '';

        services.forEach(service => {
            console.log('services.js: Processando serviço:', service);
            const card = document.createElement('div');
            card.classList.add('service-card');
            if (service.status === 'inativo') {
                card.classList.add('inactive');
            }

            const statusLabel = service.status.charAt(0).toUpperCase() + service.status.slice(1);
            const statusClass = service.status === 'inativo' ? 'inactive' : '';

            card.innerHTML = `
                <div class="service-header">
                    <div class="status-badge ${statusClass}">${statusLabel}</div>
                    <h3>${service.nome}</h3>
                    <p>${service.descricao}</p>
                </div>
                <div class="service-body">
                    <div class="service-details">
                        <div class="detail-row">
                            <span>Duração:</span>
                            <span>${service.duracao} minutos</span>
                        </div>
                        <div class="detail-row">
                            <span>Preço:</span>
                            <span>R$ ${service.preco}</span>
                        </div>
                        <div class="detail-row">
                            <span>Agendamentos:</span>
                            <span>${service.agendamentos} este mês</span>
                        </div>
                        <div class="detail-row">
                            <span>Consultores:</span>
                            <span>${service.consultores_disponiveis} disponíveis</span>
                        </div>
                    </div>
                    <div class="service-description">
                        ${service.descricao}
                    </div>
                </div>
                <div class="service-footer">
                    <button class="btn-outline edit" data-id="${service.id}">
                        <i class="fas fa-edit"></i> Editar
                    </button>
                    <button class="btn-outline toggle-status" data-id="${service.id}" data-status="${service.status}">
                        <i class="fas fa-toggle-${service.status === 'ativo' ? 'on' : 'off'}"></i>
                        ${service.status === 'ativo' ? 'Desativar' : 'Ativar'}
                    </button>
                </div>
            `;
            servicesGrid.appendChild(card);
        });

        setupActionButtons();
    }

    // Configurar eventos
    function setupEventListeners() {
        console.log('services.js: Configurando eventos');
        statusSelect.addEventListener('change', () => {
            statusFilter = statusSelect.value.toLowerCase();
            console.log('services.js: Filtro de status alterado:', statusFilter);
            loadData();
        });

        searchInput.addEventListener('input', debounce(() => {
            searchQuery = searchInput.value.trim();
            console.log('services.js: Busca alterada:', searchQuery);
            loadData();
        }, 300));

        newServiceBtn.addEventListener('click', () => {
            console.log('services.js: Botão novo serviço clicado');
            alert('Funcionalidade de novo serviço será implementada em breve!');
        });
    }

    // Configurar botões de ação
    function setupActionButtons() {
        console.log('services.js: Configurando botões de ação');
        document.querySelectorAll('.btn-outline.edit').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = btn.dataset.id;
                console.log('services.js: Editando serviço ID:', id);
                const service = btn.closest('.service-card');
                const details = {
                    id: id,
                    nome: service.querySelector('h3').textContent,
                    descricao: service.querySelector('.service-description').textContent.trim(),
                    duracao: service.querySelector('.service-details .detail-row:nth-child(1) span:nth-child(2)').textContent,
                    preco: service.querySelector('.service-details .detail-row:nth-child(2) span:nth-child(2)').textContent,
                    agendamentos: service.querySelector('.service-details .detail-row:nth-child(3) span:nth-child(2)').textContent,
                    consultores: service.querySelector('.service-details .detail-row:nth-child(4) span:nth-child(2)').textContent,
                    status: service.querySelector('.status-badge').textContent
                };
                alert(`Editar Serviço ID ${id}:\nNome: ${details.nome}\nDescrição: ${details.descricao}\nDuração: ${details.duracao}\nPreço: ${details.preco}\nAgendamentos: ${details.agendamentos}\nConsultores: ${details.consultores}\nStatus: ${details.status}`);
            });
        });

        document.querySelectorAll('.btn-outline.toggle-status').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = btn.dataset.id;
                const currentStatus = btn.dataset.status;
                const action = currentStatus === 'ativo' ? 'deactivate' : 'activate';
                console.log('services.js: Alterando status do serviço ID:', id, 'para', action);

                if (confirm(`Deseja ${action === 'deactivate' ? 'desativar' : 'ativar'} este serviço?`)) {
                    fetch('../services_data.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ action: action, id: id })
                    })
                    .then(response => {
                        console.log('services.js: Status da alteração:', response.status);
                        return response.json();
                    })
                    .then(data => {
                        console.log('services.js: Resposta da alteração:', data);
                        if (data.success) {
                            alert(`Serviço ${action === 'deactivate' ? 'desativado' : 'ativado'} com sucesso!`);
                            loadData();
                        } else {
                            alert('Erro ao alterar status: ' + (data.error || 'Erro desconhecido'));
                        }
                    })
                    .catch(error => {
                        console.error('services.js: Erro ao alterar status:', error);
                        alert('Erro ao alterar status: ' + error.message);
                    });
                }
            });
        });
    }

    // Função de debounce
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // Iniciar
    initServices();
});