document.addEventListener('DOMContentLoaded', function () {
    // Variables to store selected values
    let selectedService = null;
    let selectedConsultant = null; // Will be set when consultant is selected
    let selectedDate = null;
    let selectedTime = null;
    let selectedConsultantData = null; // Will store full consultant data

    // Step navigation
    const steps = ['step1', 'step2', 'step3', 'step4'];
    const contents = ['step1-content', 'step2-content', 'step3-content', 'step4-content'];

    // Service selection
    const serviceOptions = document.querySelectorAll('.service-option');
    const serviceNextBtn = document.getElementById('service-next');

    serviceOptions.forEach(option => {
        option.addEventListener('click', function () {
            // Deselect all
            serviceOptions.forEach(opt => {
                opt.classList.remove('selected');
                opt.querySelector('.service-select i').className = 'far fa-circle';
            });

            // Select current
            this.classList.add('selected');
            this.querySelector('.service-select i').className = 'fas fa-check-circle';

            // Enable next button
            serviceNextBtn.disabled = false;

            // Store selected service data
            selectedService = {
                name: this.querySelector('h4').textContent,
                price: this.dataset.price,
                duration: this.dataset.duration,
                id: this.dataset.service
            };

            // Carregar consultores disponíveis para este serviço
            loadConsultants();
        });
    });

    // Consultant selection
    const consultantsContainer = document.querySelector('#consultant-options');
    let consultantOptions; // Será preenchido após carregar os consultores

    // Mapeamento de serviços para IDs do banco
    const serviceMap = {
        'planejamento-basico': 1,
        'consultoria-investimentos': 3,
        'analise-dividas': 4,
        'planejamento-aposentadoria': 2
    };

    // Função para carregar consultores do banco de dados
    function loadConsultants() {
        // Mostrar loading
        consultantsContainer.innerHTML = `
            <div class="consultant-loading">
                <i class="fas fa-spinner fa-spin"></i>
                <p>Carregando consultores disponíveis...</p>
            </div>
        `;

        fetch('get_consultores.php')
            .then(response => {
                if (!response.ok) throw new Error('Erro na requisição');
                return response.json();
            })
            .then(data => {
                if (!data.success) throw new Error(data.error || 'Erro ao carregar consultores');
                if (!data.consultores || data.consultores.length === 0) {
                    throw new Error('Nenhum consultor disponível');
                }

                // Limpar container
                consultantsContainer.innerHTML = '';

                let hasAvailableConsultants = false;

                // Adicionar cada consultor
                data.consultores.forEach(consultor => {
                    // Verificar se o consultor pode oferecer o serviço selecionado
                    const serviceId = selectedService ? serviceMap[selectedService.id] : null;
                    if (!serviceId || Object.keys(consultor.servicos).includes(serviceId.toString())) {
                        hasAvailableConsultants = true;
                        const consultantCard = document.createElement('div');
                        consultantCard.className = 'consultant';
                        consultantCard.dataset.consultant = consultor.id;

                        // Calcular pontuação de avaliação (exemplo: entre 4.5 e 5.0)
                        const rating = (4.5 + Math.random() * 0.5).toFixed(1);
                        const stars = '★'.repeat(Math.floor(rating)) + '☆'.repeat(5 - Math.floor(rating));

                        consultantCard.innerHTML = `
                            <img src="https://randomuser.me/api/portraits/${consultor.id % 2 ? 'men' : 'women'}/${(consultor.id * 123) % 70 + 1}.jpg" 
                                 alt="${consultor.nome}">
                            <div class="consultant-info">
                                <p class="consultant-name">${consultor.nome}</p>
                                <p class="consultant-specialties">${consultor.especialidades}</p>
                                <p class="consultant-rating">${stars} (${rating})</p>
                                <p class="consultant-availability">${consultor.disponibilidade}</p>
                            </div>
                            <div class="consultant-select">
                                <i class="far fa-circle"></i>
                            </div>
                        `;

                        // Adicionar evento de clique
                        consultantCard.addEventListener('click', function () {
                            document.querySelectorAll('.consultant').forEach(opt => {
                                opt.classList.remove('active');
                                opt.querySelector('.consultant-select i').className = 'far fa-circle';
                            });
                            this.classList.add('active');
                            this.querySelector('.consultant-select i').className = 'fas fa-check-circle';
                            selectedConsultant = consultor.id;
                            selectedConsultantData = consultor;

                            // Refresh available times if date is already selected
                            if (selectedDate) {
                                loadAvailableTimes(selectedDate, selectedConsultant);
                            }
                        });

                        consultantsContainer.appendChild(consultantCard);
                    }
                });

                if (!hasAvailableConsultants) {
                    consultantsContainer.innerHTML = `
                        <div class="no-consultants-message">
                            <i class="fas fa-user-tie"></i>
                            <p>Nenhum consultor disponível para este serviço no momento.</p>
                        </div>
                    `;
                } else {
                    // Atualizar referência aos elementos de consultor
                    consultantOptions = document.querySelectorAll('.consultant');

                    // Selecionar primeiro consultor por padrão se houver
                    if (consultantOptions.length > 0) {
                        consultantOptions[0].click();
                    }
                }
            })
            .catch(error => {
                console.error('Erro ao carregar consultores:', error);
                consultantsContainer.innerHTML = `
                    <div class="error-message">
                        <i class="fas fa-exclamation-circle"></i>
                        <p>Erro ao carregar consultores. Por favor, tente novamente.</p>
                    </div>
                `;
            });
    }

    // Calendar functionality
    const calendarDays = document.getElementById('calendar-days');
    const currentMonthElement = document.getElementById('current-month');
    const prevMonthButton = document.getElementById('prev-month');
    const nextMonthButton = document.getElementById('next-month');

    let currentDate = new Date();
    let currentMonth = currentDate.getMonth();
    let currentYear = currentDate.getFullYear();

    // Generate calendar
    function generateCalendar(month, year) {
        calendarDays.innerHTML = '';

        currentMonthElement.textContent = new Date(year, month, 1)
            .toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });

        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();

        // Previous month days
        for (let i = 0; i < firstDay; i++) {
            const dayElement = document.createElement('div');
            dayElement.classList.add('calendar-day', 'other-month', 'disabled');
            calendarDays.appendChild(dayElement);
        }

        // Current month days
        for (let i = 1; i <= daysInMonth; i++) {
            const dayElement = document.createElement('div');
            dayElement.classList.add('calendar-day');
            dayElement.textContent = i;

            const currentDateObj = new Date(year, month, i);

            // Disable past dates and weekends (if applicable)
            if (
                currentDateObj < new Date().setHours(0, 0, 0, 0) ||
                currentDateObj.getDay() === 0 // Sunday
            ) {
                dayElement.classList.add('disabled');
            } else {
                dayElement.addEventListener('click', function () {
                    // Deselect previously selected date
                    document.querySelectorAll('.calendar-day.selected').forEach(day => {
                        day.classList.remove('selected');
                    });

                    // Select current date
                    this.classList.add('selected');

                    // Store selected date
                    selectedDate = new Date(year, month, i);

                    // Update selected date display
                    updateSelectedDateDisplay(selectedDate);

                    // Load available times for this date
                    loadAvailableTimes(selectedDate, selectedConsultant);
                });
            }

            // Highlight today
            if (
                i === currentDate.getDate() &&
                month === currentDate.getMonth() &&
                year === currentDate.getFullYear()
            ) {
                dayElement.classList.add('today');
            }

            calendarDays.appendChild(dayElement);
        }
    }

    // Initialize calendar
    generateCalendar(currentMonth, currentYear);

    // Previous month button
    prevMonthButton.addEventListener('click', function () {
        currentMonth--;
        if (currentMonth < 0) {
            currentMonth = 11;
            currentYear--;
        }
        generateCalendar(currentMonth, currentYear);
    });

    // Next month button
    nextMonthButton.addEventListener('click', function () {
        currentMonth++;
        if (currentMonth > 11) {
            currentMonth = 0;
            currentYear++;
        }
        generateCalendar(currentMonth, currentYear);
    });

    // Update selected date display
    function updateSelectedDateDisplay(date) {
        const options = { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' };
        document.getElementById('selected-date-display').textContent =
            date.toLocaleDateString('pt-BR', options);
    }

    // Load available times from backend
    function loadAvailableTimes(date, consultantId) {
        const timeSlotsContainer = document.getElementById('time-slots-container');
        timeSlotsContainer.innerHTML = ''; // Clear previous slots

        const selectedDateStr = date.toLocaleDateString('pt-BR');
        document.getElementById('selected-date-display').textContent = `Horários para ${selectedDateStr}`;

        if (!selectedService) {
            const noServiceMsg = document.createElement('p');
            noServiceMsg.textContent = 'Por favor, selecione um serviço primeiro.';
            noServiceMsg.classList.add('text-center', 'text-muted');
            timeSlotsContainer.appendChild(noServiceMsg);
            return;
        }

        // Mapeia serviços do frontend para IDs do banco
        const serviceMap = {
            'planejamento-basico': 1, // Consultoria Financeira
            'consultoria-investimentos': 3, // Consultoria de Investimentos
            'analise-dividas': 4, // Gestão de Dívidas
            'planejamento-aposentadoria': 2 // Planejamento de Aposentadoria
        };

        // Mapeia consultores do frontend para IDs do banco
        const consultantMap = {
            'carlos-silva': 1, // Carlos Rodrigues
            'ana-oliveira': 2 // Ana Oliveira
        };

        const serviceId = serviceMap[selectedService.id];
        // Formata a data para o formato YYYY-MM-DD e ajusta para o fuso horário local
        const formattedDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000))
            .toISOString().split('T')[0];

        // Faz requisição AJAX para obter horários disponíveis
        fetch(`get_available_times.php?consultant_id=${consultantId}&date=${formattedDate}&service_id=${serviceId}`)
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    const errorMsg = document.createElement('p');
                    errorMsg.textContent = data.error;
                    errorMsg.classList.add('text-center', 'text-danger');
                    timeSlotsContainer.appendChild(errorMsg);
                    return;
                }

                const availableTimes = data.times || [];
                let hasAvailableSlots = false;

                availableTimes.forEach(time => {
                    const timeSlotButton = document.createElement('button');
                    timeSlotButton.classList.add('time-slot');
                    timeSlotButton.textContent = time;
                    timeSlotButton.addEventListener('click', function () {
                        document.querySelectorAll('.time-slot.selected').forEach(slot => slot.classList.remove('selected'));
                        this.classList.add('selected');
                        selectedTime = time;
                        document.getElementById('date-next').disabled = false;
                    });
                    timeSlotsContainer.appendChild(timeSlotButton);
                    hasAvailableSlots = true;
                });

                if (!hasAvailableSlots) {
                    const noSlotsMsg = document.createElement('p');
                    noSlotsMsg.textContent = 'Nenhum horário disponível para esta data e consultor.';
                    noSlotsMsg.classList.add('text-center', 'text-muted', 'mt-2');
                    timeSlotsContainer.appendChild(noSlotsMsg);
                }
            })
            .catch(error => {
                const errorMsg = document.createElement('p');
                errorMsg.textContent = 'Erro ao carregar horários disponíveis.';
                errorMsg.classList.add('text-center', 'text-danger');
                timeSlotsContainer.appendChild(errorMsg);
            });

        selectedTime = null;
        document.getElementById('date-next').disabled = true;
        document.querySelectorAll('.time-slot.selected').forEach(slot => slot.classList.remove('selected'));
    }

    // Navigation buttons
    serviceNextBtn.addEventListener('click', function () {
        goToStep(1);
    });

    document.getElementById('date-prev').addEventListener('click', function () {
        goToStep(0);
    });

    document.getElementById('date-next').addEventListener('click', function () {
        if (selectedDate && selectedTime) {
            goToStep(2);
        } else {
            alert('Por favor, selecione data e horário para continuar.');
        }
    });

    document.getElementById('info-prev').addEventListener('click', function () {
        goToStep(1);
    });

    document.getElementById('info-next').addEventListener('click', function () {
        const form = document.getElementById('personal-info-form');
        const inputs = form.querySelectorAll('input[required]');
        let isValid = true;

        // Simple validation
        inputs.forEach(input => {
            if (!input.value.trim()) {
                isValid = false;
                input.style.borderColor = '#ff6b6b';
            } else {
                input.style.borderColor = '#ddd';
            }
        });

        if (isValid) {
            // Update confirmation page
            updateConfirmationPage();
            goToStep(3);
        } else {
            alert('Por favor, preencha todos os campos obrigatórios.');
        }
    });

    document.getElementById('confirm-prev').addEventListener('click', function () {
        goToStep(2);
    });

    // Terms checkbox
    document.getElementById('terms-check').addEventListener('change', function () {
        document.getElementById('confirm-appointment').disabled = !this.checked;
    });

    // Confirm appointment button
    document.getElementById('confirm-appointment').addEventListener('click', function () {
        // Get client info
        const clientName = document.getElementById('fullname').value;
        const clientEmail = document.getElementById('email').value;
        const clientPhone = document.getElementById('phone').value;
        const comments = document.getElementById('comments').value;

        // Mapeia serviços e consultores para IDs do banco
        const serviceMap = {
            'planejamento-basico': 1,
            'consultoria-investimentos': 3,
            'analise-dividas': 4,
            'planejamento-aposentadoria': 2
        };
        const consultantMap = {
            'carlos-silva': 1,
            'ana-oliveira': 2
        };

        // Formata a data
        const formattedDate = selectedDate.getFullYear() + '-' +
            ('0' + (selectedDate.getMonth() + 1)).slice(-2) + '-' +
            ('0' + selectedDate.getDate()).slice(-2);

        const appointmentData = {
            service_id: serviceMap[selectedService.id],
            consultant_id: selectedConsultant,
            date: formattedDate,
            time: selectedTime,
            client: {
                name: clientName,
                email: clientEmail,
                phone: clientPhone,
                comments: comments
            }
        };

        // Envia dados para o backend via AJAX
        fetch('agendamento.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(appointmentData)
        })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    alert('Erro: ' + data.error);
                    return;
                }

                // Mostra mensagem de sucesso
                document.querySelector('.scheduling-steps').style.display = 'none';
                document.querySelectorAll('.step-content').forEach(content => {
                    content.style.display = 'none';
                });

                document.getElementById('reference-number').textContent = data.reference_number;
                document.getElementById('success-message').style.display = 'block';
            })
            .catch(error => {
                alert('Erro ao confirmar o agendamento: ' + error.message);
            });
    });

    // Add to calendar button
    document.getElementById('add-to-calendar').addEventListener('click', function () {
        // Generate calendar file or link (could be Google Calendar, iCal, etc)
        alert('Funcionalidade de adicionar ao calendário será implementada em breve!');
    });

    // Navigation function
    function goToStep(stepIndex) {
        // Hide all content
        contents.forEach(content => {
            document.getElementById(content).classList.remove('visible');
        });

        // Show selected content
        document.getElementById(contents[stepIndex]).classList.add('visible');

        // Update steps indicator
        steps.forEach((step, index) => {
            const stepElement = document.getElementById(step);

            if (index < stepIndex) {
                stepElement.classList.remove('active');
                stepElement.classList.add('completed');
            } else if (index === stepIndex) {
                stepElement.classList.add('active');
                stepElement.classList.remove('completed');
            } else {
                stepElement.classList.remove('active');
                stepElement.classList.remove('completed');
            }
        });

        // Scroll to top of container
        document.querySelector('.scheduling-container').scrollIntoView({ behavior: 'smooth' });
    }

    // Update confirmation page with selected information
    function updateConfirmationPage() {
        // Get form values
        const name = document.getElementById('fullname').value;
        const email = document.getElementById('email').value;
        const phone = document.getElementById('phone').value;

        // Format date
        const formattedDate = selectedDate.toLocaleDateString('pt-BR', {
            day: 'numeric',
            month: 'long',
            year: 'numeric'
        });

        // Display consultant name
        const consultantName = selectedConsultantData ? selectedConsultantData.nome : 'Não selecionado';

        // Update confirmation fields
        document.getElementById('confirm-service').textContent = selectedService.name;
        document.getElementById('confirm-consultant').textContent = consultantName;
        document.getElementById('confirm-date').textContent = formattedDate;
        document.getElementById('confirm-time').textContent = selectedTime;
        document.getElementById('confirm-duration').textContent = selectedService.duration;
        document.getElementById('confirm-price').textContent = `R$ ${selectedService.price}`;

        document.getElementById('confirm-name').textContent = name;
        document.getElementById('confirm-email').textContent = email;
        document.getElementById('confirm-phone').textContent = phone;
    }
});