   <?php
header('Content-Type: application/json');
require_once 'config.php';

try {
    // Recebe os dados do formulário via POST
    $data = json_decode(file_get_contents('php://input'), true);

    // Valida os dados recebidos
    if (!isset($data['service_id']) || !isset($data['consultant_id']) || 
        !isset($data['date']) || !isset($data['time']) || 
        !isset($data['client']['name']) || !isset($data['client']['email']) || 
        !isset($data['client']['phone'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Dados incompletos']);
        exit;
    }

    // Sanitiza os dados
    $service_id = sanitizeInput($data['service_id']);
    $consultant_id = sanitizeInput($data['consultant_id']);
    $date = sanitizeInput($data['date']);
    $time = sanitizeInput($data['time']);
    $client_name = sanitizeInput($data['client']['name']);
    $client_email = sanitizeInput($data['client']['email']);
    $client_phone = sanitizeInput($data['client']['phone']);
    $comments = isset($data['client']['comments']) ? sanitizeInput($data['client']['comments']) : '';

    // Valida formato do e-mail
    if (!filter_var($client_email, FILTER_VALIDATE_EMAIL)) {
        http_response_code(400);
        echo json_encode(['error' => 'E-mail inválido']);
        exit;
    }

    // Valida formato do telefone (ex.: (XX) XXXXX-XXXX ou (XX) XXXX-XXXX)
    if (!preg_match('/^\(\d{2}\)\s?\d{4,5}-\d{4}$/', $client_phone)) {
        http_response_code(400);
        echo json_encode(['error' => 'Telefone inválido']);
        exit;
    }

    // Valida formato da data (YYYY-MM-DD)
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        http_response_code(400);
        echo json_encode(['error' => 'Data inválida']);
        exit;
    }

    // Valida formato do horário (HH:MM)
    if (!preg_match('/^\d{2}:\d{2}$/', $time)) {
        http_response_code(400);
        echo json_encode(['error' => 'Horário inválido']);
        exit;
    }

    // Combina data e horário
    $datetime = DateTime::createFromFormat('Y-m-d H:i', "$date $time");
    if (!$datetime) {
        http_response_code(400);
        echo json_encode(['error' => 'Data ou horário inválido']);
        exit;
    }

    // Verifica se o serviço existe e obtém a duração
    $stmt = $pdo->prepare("SELECT duracao FROM servicos WHERE id = ? AND status = 'ativo'");
    $stmt->execute([$service_id]);
    $service = $stmt->fetch();
    if (!$service) {
        http_response_code(400);
        echo json_encode(['error' => 'Serviço inválido ou inativo']);
        exit;
    }
    $duration = $service['duracao'];

    // Verifica se o consultor existe e está ativo
    $stmt = $pdo->prepare("SELECT id FROM consultores WHERE id = ? AND status = 'ativo'");
    $stmt->execute([$consultant_id]);
    if (!$stmt->fetch()) {
        http_response_code(400);
        echo json_encode(['error' => 'Consultor inválido ou inativo']);
        exit;
    }    // Verifica se o consultor oferece o serviço
    $stmt = $pdo->prepare("
        SELECT cs.consultor_id 
        FROM consultores_servicos cs
        JOIN consultores c ON cs.consultor_id = c.id
        JOIN servicos s ON cs.servico_id = s.id
        WHERE cs.consultor_id = ? 
        AND cs.servico_id = ?
        AND c.status = 'ativo'
        AND s.status = 'ativo'
    ");
    $stmt->execute([$consultant_id, $service_id]);
    if (!$stmt->fetch()) {
        http_response_code(400);
        echo json_encode(['error' => 'Consultor não oferece este serviço ou não está disponível']);
        exit;
    }

    // Verifica conflitos de horário
    $end_datetime = clone $datetime;
    $end_datetime->modify("+$duration minutes");
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count
        FROM agendamentos
        WHERE consultor_id = ?
        AND data_hora < ? 
        AND DATE_ADD(data_hora, INTERVAL duracao MINUTE) > ?
        AND status IN ('pendente', 'confirmado')
    ");
    $stmt->execute([$consultant_id, $end_datetime->format('Y-m-d H:i:s'), $datetime->format('Y-m-d H:i:s')]);
    if ($stmt->fetch()['count'] > 0) {
        http_response_code(400);
        echo json_encode(['error' => 'Horário já ocupado']);
        exit;
    }

    // Inicia transação
    $pdo->beginTransaction();

    // Verifica se o cliente já existe pelo e-mail
    $stmt = $pdo->prepare("SELECT id FROM clientes WHERE email = ?");
    $stmt->execute([$client_email]);
    $client = $stmt->fetch();

    if ($client) {
        $client_id = $client['id'];
    } else {
        // Insere novo cliente
        $stmt = $pdo->prepare("
            INSERT INTO clientes (nome, email, telefone)
            VALUES (?, ?, ?)
        ");
        $stmt->execute([$client_name, $client_email, $client_phone]);
        $client_id = $pdo->lastInsertId();
    }

    // Insere o agendamento
    $stmt = $pdo->prepare("
        INSERT INTO agendamentos (cliente_id, consultor_id, servico_id, data_hora, duracao, status)
        VALUES (?, ?, ?, ?, ?, 'pendente')
    ");
    $stmt->execute([$client_id, $consultant_id, $service_id, $datetime->format('Y-m-d H:i:s'), $duration]);

    $appointment_id = 'FC' . str_pad($pdo->lastInsertId(), 8, '0', STR_PAD_LEFT);

    // Atualiza total de agendamentos do consultor
    $stmt = $pdo->prepare("
        UPDATE consultores
        SET total_agendamentos = total_agendamentos + 1
        WHERE id = ?
    ");
    $stmt->execute([$consultant_id]);

    $pdo->commit();

    // Retorna resposta de sucesso
    echo json_encode([
        'success' => true,
        'reference_number' => $appointment_id,
        'message' => 'Agendamento realizado com sucesso!'
    ]);

} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['error' => 'Erro ao processar o agendamento: ' . $e->getMessage()]);
}
?>