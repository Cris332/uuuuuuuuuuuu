<?php
header('Content-Type: application/json');
require_once 'config.php';

// Habilitar logs para depuração
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'C:/xampp/php/logs/php_error_log');
error_log('appointments_data.php: Iniciando requisição');

try {
    // Verificar método da requisição
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        error_log('appointments_data.php: Requisição POST recebida');
        $input = json_decode(file_get_contents('php://input'), true);
        if (isset($input['action']) && $input['action'] === 'cancel' && isset($input['id'])) {
            error_log('appointments_data.php: Cancelando agendamento ID ' . $input['id']);
            $stmt = $pdo->prepare("UPDATE agendamentos SET status = 'cancelado', updated_at = NOW() WHERE id = ?");
            $stmt->execute([(int)$input['id']]);
            echo json_encode(['success' => true]);
            exit;
        }
        throw new Exception('Ação POST inválida');
    }

    // Parâmetros GET
    $consultant_id = isset($_GET['consultant_id']) ? (int)$_GET['consultant_id'] : 0;
    $status = isset($_GET['status']) ? trim($_GET['status']) : '';
    $month_year = isset($_GET['month_year']) ? trim($_GET['month_year']) : '';
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $per_page = isset($_GET['per_page']) ? (int)$_GET['per_page'] : 6;

    error_log('appointments_data.php: Parâmetros recebidos - consultant_id: ' . $consultant_id . ', status: ' . $status . ', month_year: ' . $month_year . ', search: ' . $search . ', page: ' . $page . ', per_page: ' . $per_page);

    // Validar parâmetros
    if ($page < 1) $page = 1;
    if (!in_array($per_page, [6, 12, 24, 0])) $per_page = 6;
    $offset = ($page - 1) * $per_page;

    // Montar query base
    $query = "
        SELECT a.id, a.data_hora, a.duracao, a.status, 
               c.nome as cliente_nome, c.email as cliente_email,
               co.nome as consultor_nome, co.id as consultor_id,
               s.nome as servico_nome
        FROM agendamentos a
        JOIN clientes c ON a.cliente_id = c.id
        JOIN consultores co ON a.consultor_id = co.id
        JOIN servicos s ON a.servico_id = s.id
        WHERE 1=1
    ";
    $params = [];

    // Filtro por consultor
    if ($consultant_id > 0) {
        $query .= " AND a.consultor_id = ?";
        $params[] = $consultant_id;
    }

    // Filtro por status
    if ($status && in_array($status, ['pendente', 'confirmado', 'cancelado', 'concluido'])) {
        $query .= " AND a.status = ?";
        $params[] = $status;
    }

    // Filtro por mês/ano
    if ($month_year && preg_match('/^(\d{2})-(\d{4})$/', $month_year, $matches)) {
        $month = (int)$matches[1];
        $year = (int)$matches[2];
        $monthStart = new DateTime("$year-$month-01 00:00:00");
        $monthEnd = (clone $monthStart)->modify('last day of this month')->setTime(23, 59, 59);
        $query .= " AND a.data_hora BETWEEN ? AND ?";
        $params[] = $monthStart->format('Y-m-d H:i:s');
        $params[] = $monthEnd->format('Y-m-d H:i:s');
    }

    // Busca por cliente
    if ($search) {
        $query .= " AND (c.nome LIKE ? OR c.email LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }

    // Contar total de registros
    $countQuery = str_replace('SELECT a.id, a.data_hora, a.duracao, a.status, c.nome as cliente_nome, c.email as cliente_email, co.nome as consultor_nome, co.id as consultor_id, s.nome as servico_nome', 'SELECT COUNT(*) as total', $query);
    $stmt = $pdo->prepare($countQuery);
    $stmt->execute($params);
    $total_records = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    error_log('appointments_data.php: Total de registros: ' . $total_records);

    // Adicionar ordenação
    $query .= " ORDER BY a.data_hora DESC";

    // Adicionar paginação (evitar placeholders para LIMIT e OFFSET)
    if ($per_page > 0) {
        $query .= " LIMIT $per_page OFFSET $offset";
    }

    // Executar query principal
    error_log('appointments_data.php: Executando query: ' . $query);
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    error_log('appointments_data.php: Agendamentos retornados: ' . count($appointments));

    // Formatar dados
    $data = array_map(function($appt) {
        $apptDate = new DateTime($appt['data_hora']);
        return [
            'id' => $appt['id'],
            'cliente_nome' => $appt['cliente_nome'],
            'cliente_email' => $appt['cliente_email'],
            'consultor_nome' => $appt['consultor_nome'],
            'consultor_id' => $appt['consultor_id'],
            'servico_nome' => $appt['servico_nome'],
            'data' => $apptDate->format('d/m/Y'),
            'horario' => $apptDate->format('H:i'),
            'status' => $appt['status'],
            'avatar' => strtoupper(substr($appt['cliente_nome'], 0, 2))
        ];
    }, $appointments);

    // Lista de consultores
    $stmt = $pdo->query("SELECT id, nome FROM consultores WHERE status = 'ativo' ORDER BY nome");
    $consultants = $stmt->fetchAll(PDO::FETCH_ASSOC);
    error_log('appointments_data.php: Consultores retornados: ' . count($consultants));

    // Lista de meses
    $stmt = $pdo->query("SELECT DISTINCT DATE_FORMAT(data_hora, '%m-%Y') as month_year FROM agendamentos ORDER BY data_hora DESC LIMIT 12");
    $months = $stmt->fetchAll(PDO::FETCH_COLUMN);
    error_log('appointments_data.php: Meses retornados: ' . count($months));

    // Resposta
    echo json_encode([
        'success' => true,
        'appointments' => $data,
        'total_records' => $total_records,
        'consultants' => $consultants,
        'months' => $months,
        'current_page' => $page,
        'per_page' => $per_page
    ]);
    error_log('appointments_data.php: Resposta enviada com sucesso');

} catch (Exception $e) {
    error_log('appointments_data.php: Erro capturado: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Erro ao carregar dados: ' . $e->getMessage()]);
}
?>