<?php
header('Content-Type: application/json');
require_once 'config.php';

try {
    // Parâmetros da requisição
    $month = isset($_GET['month']) ? (int)$_GET['month'] : 6; // Mês atual: junho
    $year = isset($_GET['year']) ? (int)$_GET['year'] : 2025; // Ano atual: 2025
    $consultant_id = isset($_GET['consultant_id']) ? (int)$_GET['consultant_id'] : 0; // 0 = todos
    $service_id = isset($_GET['service_id']) ? (int)$_GET['service_id'] : 0; // 0 = todos

    // Validar mês e ano
    if ($month < 1 || $month > 12) $month = 6;
    if ($year < 2000 || $year > 2100) $year = 2025;

    // Definir intervalo de datas
    $monthStart = new DateTime("$year-$month-01 00:00:00");
    $monthEnd = (clone $monthStart)->modify('last day of this month')->setTime(23, 59, 59);

    // Montar a query de agendamentos
    $query = "
        SELECT a.id, a.data_hora, a.duracao, a.status, 
               c.nome as cliente_nome, co.nome as consultor_nome, 
               s.nome as servico_nome, s.id as servico_id
        FROM agendamentos a
        JOIN clientes c ON a.cliente_id = c.id
        JOIN consultores co ON a.consultor_id = co.id
        JOIN servicos s ON a.servico_id = s.id
        WHERE a.data_hora BETWEEN ? AND ?
        AND a.status IN ('pendente', 'confirmado', 'concluido')
    ";
    $params = [$monthStart->format('Y-m-d H:i:s'), $monthEnd->format('Y-m-d H:i:s')];

    if ($consultant_id > 0) {
        $query .= " AND a.consultor_id = ?";
        $params[] = $consultant_id;
    }
    if ($service_id > 0) {
        $query .= " AND a.servico_id = ?";
        $params[] = $service_id;
    }

    $query .= " ORDER BY a.data_hora";

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Organizar agendamentos por dia
    $calendarData = [];
    $daysInMonth = (int)$monthStart->format('t');
    $firstDayOfWeek = (int)$monthStart->format('w'); // 0 (Domingo) a 6 (Sábado)

    // Preencher dias do mês
    for ($day = 1; $day <= $daysInMonth; $day++) {
        $calendarData[$day] = [
            'day_number' => $day,
            'events' => []
        ];
    }

    // Adicionar dias inativos do mês anterior
    $prevMonthDays = $firstDayOfWeek;
    $prevMonth = (clone $monthStart)->modify('-1 month');
    $prevMonthDaysInMonth = (int)$prevMonth->format('t');
    for ($i = $prevMonthDays - 1; $i >= 0; $i--) {
        $calendarData[-$i] = [
            'day_number' => $prevMonthDaysInMonth - $i,
            'inactive' => true
        ];
    }

    // Preencher agendamentos
    foreach ($appointments as $appt) {
        $apptDate = new DateTime($appt['data_hora']);
        $day = (int)$apptDate->format('j');
        $serviceClass = [
            1 => 'event-primary', // Consultoria Financeira
            2 => 'event-success', // Planejamento de Aposentadoria
            3 => 'event-warning', // Consultoria de Investimentos
            4 => 'event-purple'   // Gestão de Dívidas
        ][$appt['servico_id']] ?? 'event-primary';

        $calendarData[$day]['events'][] = [
            'id' => $appt['id'],
            'time' => $apptDate->format('H:i'),
            'consultant' => $appt['consultor_nome'],
            'client' => $appt['cliente_nome'],
            'service' => $appt['servico_nome'],
            'duration' => $appt['duracao'] >= 120 ? '2 horas' : 
                         ($appt['duracao'] >= 90 ? '1h30min' : '1 hora'),
            'status' => $appt['status'],
            'class' => $serviceClass
        ];
    }

    // Estatísticas
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total
        FROM agendamentos
        WHERE data_hora BETWEEN ? AND ?
        AND status IN ('pendente', 'confirmado', 'concluido')
    ");
    $stmt->execute([$monthStart->format('Y-m-d H:i:s'), $monthEnd->format('Y-m-d H:i:s')]);
    $totalAppointments = $stmt->fetch()['total'];

    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total
        FROM agendamentos
        WHERE data_hora BETWEEN ? AND ?
        AND status = 'confirmado'
    ");
    $stmt->execute([$monthStart->format('Y-m-d H:i:s'), $monthEnd->format('Y-m-d H:i:s')]);
    $confirmedAppointments = $stmt->fetch()['total'];

    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total
        FROM agendamentos
        WHERE data_hora BETWEEN ? AND ?
        AND status = 'pendente'
    ");
    $stmt->execute([$monthStart->format('Y-m-d H:i:s'), $monthEnd->format('Y-m-d H:i:s')]);
    $pendingAppointments = $stmt->fetch()['total'];

    $progress = round((new DateTime())->format('j') / $daysInMonth * 100);

    // Lista de consultores
    $stmt = $pdo->query("SELECT id, nome FROM consultores WHERE status = 'ativo' ORDER BY nome");
    $consultants = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Lista de serviços
    $stmt = $pdo->query("SELECT id, nome FROM servicos ORDER BY nome");
    $services = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Retorna os dados
    echo json_encode([
        'success' => true,
        'month' => $month,
        'year' => $year,
        'calendar' => array_values($calendarData),
        'stats' => [
            'totalAppointments' => $totalAppointments,
            'confirmedAppointments' => $confirmedAppointments,
            'pendingAppointments' => $pendingAppointments,
            'progress' => $progress
        ],
        'consultants' => $consultants,
        'services' => $services
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erro ao carregar dados: ' . $e->getMessage()]);
}
?>