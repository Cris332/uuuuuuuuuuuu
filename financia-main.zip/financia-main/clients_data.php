<?php
header('Content-Type: application/json');

// Habilitar logs e exibição de erros
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', 'C:/xampp/php/logs/php_error_log.txt');
ini_set('error_reporting', E_ALL);
error_log('clients_data.php: Iniciando requisição em ' . date('Y-m-d H:i:s'));

try {
    // Incluir config.php
    error_log('clients_data.php: Tentando incluir config.php');
    if (!file_exists('config.php')) {
        throw new Exception('Arquivo config.php não encontrado');
    }
    require_once 'config.php';
    error_log('clients_data.php: config.php incluído com sucesso');

    // Testar conexão
    error_log('clients_data.php: Executando SELECT 1 AS test');
    $stmt = $pdo->query('SELECT 1 AS test');
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    error_log('clients_data.php: Resultado bruto: ' . json_encode($result) . ', Tipo: ' . gettype($result['test']));
    if (!isset($result['test']) || $result['test'] != 1) {
        throw new Exception('Teste SELECT 1 falhou. Resultado: ' . json_encode($result));
    }
    error_log('clients_data.php: Teste SELECT 1 passou');

    // Verificar tabelas
    error_log('clients_data.php: Verificando tabela clientes');
    $stmt = $pdo->query("SHOW TABLES LIKE 'clientes'");
    if ($stmt->rowCount() === 0) {
        throw new Exception('Tabela clientes não existe');
    }

    error_log('clients_data.php: Verificando tabela servicos');
    $stmt = $pdo->query("SHOW TABLES LIKE 'servicos'");
    if ($stmt->rowCount() === 0) {
        throw new Exception('Tabela servicos não existe');
    }

    error_log('clients_data.php: Verificando tabela agendamentos');
    $stmt = $pdo->query("SHOW TABLES LIKE 'agendamentos'");
    if ($stmt->rowCount() === 0) {
        throw new Exception('Tabela agendamentos não existe');
    }
    error_log('clients_data.php: Todas as tabelas confirmadas');

    // Parâmetros GET
    $status = isset($_GET['status']) ? trim($_GET['status']) : '';
    $service = isset($_GET['service']) ? trim($_GET['service']) : '';
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    $page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) && in_array($_GET['limit'], ['6', '12', '24', '48']) ? (int)$_GET['limit'] : 6;
    $offset = ($page - 1) * $limit;

    error_log('clients_data.php: Parâmetros - status: ' . $status . ', service: ' . $service . ', search: ' . $search . ', page: ' . $page . ', limit: ' . $limit);

    // Query para clientes
    $query = "
        SELECT 
            c.id, 
            c.nome, 
            c.email, 
            c.telefone, 
            c.data_cadastro, 
            c.status,
            s.nome AS ultimo_servico,
            a.valor AS valor_total
        FROM clientes c
        LEFT JOIN (
            SELECT cliente_id, servico_id, valor,
                   ROW_NUMBER() OVER (PARTITION BY cliente_id ORDER BY data_agendamento DESC) AS rn
            FROM agendamentos
        ) a ON c.id = a.cliente_id AND a.rn = 1
        LEFT JOIN servicos s ON a.servico_id = s.id
        WHERE 1=1
    ";
    $params = [];

    // Filtro por status
    if ($status && in_array($status, ['ativo', 'inativo', 'pendente'])) {
        $query .= " AND c.status = ?";
        $params[] = $status;
    }

    // Filtro por serviço
    if ($service) {
        $query .= " AND s.nome = ?";
        $params[] = $service;
    }

    // Busca por nome ou email
    if ($search) {
        $query .= " AND (c.nome LIKE ? OR c.email LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }

    // Contar total de registros
    $count_query = str_replace(
        "SELECT c.id, c.nome, c.email, c.telefone, c.data_cadastro, c.status, s.nome AS ultimo_servico, a.valor AS valor_total",
        "SELECT COUNT(DISTINCT c.id) AS total",
        $query
    );
    $stmt = $pdo->prepare($count_query);
    $stmt->execute($params);
    $total_records = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

    // Ordenação e paginação
    $query .= " ORDER BY c.nome ASC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;

    // Executar query
    error_log('clients_data.php: Executando query: ' . $query . ' com params: ' . json_encode($params));
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $clients = $stmt->fetchAll(PDO::FETCH_ASSOC);
    error_log('clients_data.php: Clientes retornados: ' . count($clients));

    // Formatar dados
    $data = array_map(function($client) {
        return [
            'id' => $client['id'],
            'nome' => $client['nome'],
            'email' => $client['email'],
            'telefone' => $client['telefone'] ?? 'N/A',
            'data_cadastro' => date('d/m/Y', strtotime($client['data_cadastro'])),
            'status' => $client['status'],
            'ultimo_servico' => $client['ultimo_servico'] ?? 'Nenhum',
            'valor_total' => 'R$ ' . number_format($client['valor_total'] ?? 0, 2, ',', '.')
        ];
    }, $clients);

    // Obter serviços para filtro
    error_log('clients_data.php: Consultando serviços');
    $stmt = $pdo->query("SELECT nome FROM servicos WHERE status = 'ativo' ORDER BY nome");
    $services = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // Resposta
    $response = [
        'success' => true,
        'clients' => $data,
        'total_records' => $total_records,
        'services' => $services,
        'current_page' => $page,
        'total_pages' => ceil($total_records / $limit)
    ];
    error_log('clients_data.php: Resposta preparada: ' . json_encode($response, JSON_UNESCAPED_UNICODE));
    echo json_encode($response);

} catch (Exception $e) {
    error_log('clients_data.php: Erro capturado: ' . $e->getMessage() . ' em linha ' . $e->getLine());
    http_response_code(500);
    echo json_encode(['error' => 'Erro ao carregar dados: ' . $e->getMessage()]);
}
?>