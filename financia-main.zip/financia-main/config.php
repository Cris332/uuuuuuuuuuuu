<?php
// Configuração da conexão com o banco de dados
$host = 'localhost';
$dbname = 'financeconsult';
$username = 'root'; // Ajuste se necessário
$password = ''; // Ajuste se necessário

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die(json_encode(['error' => 'Erro na conexão com o banco de dados: ' . $e->getMessage()]));
}

// Função para sanitizar entrada
function sanitizeInput($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}
?>


