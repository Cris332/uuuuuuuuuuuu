<?php
header('Content-Type: application/json');

// Habilitar logs para depuração
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'C:/xampp/php/logs/php_error_log.txt');
error_log('consultants_data.php: Iniciando requisição em ' . date('Y-m-d H:i:s'));

try {
    // Tentar incluir config.php
    error_log('consultants_data.php: Tentando incluir config.php');
    require_once 'config.php';
    error_log('consultants_data.php: config.php incluído com sucesso');

    // Verificar conexão com o banco
    error_log('consultants_data.php: Verificando conexão com o banco');
    $pdo->query('SELECT 1');
    error_log('consultants_data.php: Conexão com o banco confirmada');    // Parâmetros de filtro
    $status = isset($_GET['status']) ? $_GET['status'] : '';
    $service = isset($_GET['service']) ? $_GET['service'] : '';
    $search = isset($_GET['search']) ? $_GET['search'] : '';

    // Query base para consultores
    $query = "
        SELECT 
            c.id,
            c.nome,
            c.email,
            c.telefone,
            c.especialidades as especialidade,
            c.disponibilidade,
            c.status,
            c.avaliacao_media as media_avaliacao,
            COALESCE((
                SELECT COUNT(*)
                FROM agendamentos a
                WHERE a.consultor_id = c.id
                AND MONTH(a.data_hora) = MONTH(CURRENT_DATE)
                AND YEAR(a.data_hora) = YEAR(CURRENT_DATE)
            ), 0) as agendamentos,
            (
                SELECT COUNT(*)
                FROM avaliacoes av
                WHERE av.consultor_id = c.id
            ) as total_avaliacoes
        FROM consultores c
        WHERE 1=1
    ";
    $params = [];

    // Aplicar filtros
    if ($status) {
        $query .= " AND c.status = ?";
        $params[] = $status;
    }

    if ($search) {
        $query .= " AND (c.nome LIKE ? OR c.email LIKE ? OR c.especialidades LIKE ?)";
        $searchTerm = "%$search%";
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $params[] = $searchTerm;
    }

    if ($service) {
        $query .= " AND c.id IN (
            SELECT cs.consultor_id 
            FROM consultores_servicos cs 
            JOIN servicos s ON cs.servico_id = s.id 
            WHERE s.nome = ?
        )";
        $params[] = $service;
    }

    // Ordenação
    $query .= " ORDER BY c.nome ASC";

    // Executar query
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $consultants = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Buscar serviços disponíveis
    $stmt = $pdo->query("SELECT DISTINCT nome FROM servicos WHERE status = 'ativo' ORDER BY nome");
    $services = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // Resposta
    $response = [
        'success' => true,
        'consultants' => $consultants,
        'total_records' => count($consultants),
        'services' => $services
    ];
    error_log('consultants_data.php: Resposta preparada: ' . json_encode($response, JSON_UNESCAPED_UNICODE));
    echo json_encode($response);
    error_log('consultants_data.php: Resposta enviada com sucesso');

} catch (Exception $e) {
    error_log('consultants_data.php: Erro capturado: ' . $e->getMessage() . ' em linha ' . $e->getLine());
    http_response_code(500);
    echo json_encode(['error' => 'Erro ao carregar dados: ' . $e->getMessage()]);
}
?>