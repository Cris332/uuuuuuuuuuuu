<?php
header('Content-Type: application/json');
require_once 'config.php';

try {
    // Definir a data atual e o intervalo da semana
    $today = new DateTime(); // Data atual: 16/06/2025
    $weekStart = new DateTime('2025-06-01'); // Início da semana exibida no dashboard
    $weekEnd = new DateTime('2025-06-07'); // Fim da semana exibida no dashboard
    $monthStart = new DateTime('2025-06-01 00:00:00');
    $monthEnd = new DateTime('2025-06-30 23:59:59');

    // Stats Cards
    // 1. Agendamentos este mês
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total
        FROM agendamentos
        WHERE data_hora BETWEEN ? AND ?
        AND status IN ('pendente', 'confirmado', 'concluido')
    ");
    $stmt->execute([$monthStart->format('Y-m-d H:i:s'), $monthEnd->format('Y-m-d H:i:s')]);
    $appointmentsThisMonth = $stmt->fetch()['total'];

    // 2. Receita do mês
    $stmt = $pdo->prepare("
        SELECT SUM(s.preco) as revenue
        FROM agendamentos a
        JOIN servicos s ON a.servico_id = s.id
        WHERE a.data_hora BETWEEN ? AND ?
        AND a.status IN ('confirmado', 'concluido')
    ");
    $stmt->execute([$monthStart->format('Y-m-d H:i:s'), $monthEnd->format('Y-m-d H:i:s')]);
    $revenueThisMonth = $stmt->fetch()['revenue'] ?? 0;

    // 3. Novos clientes
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total
        FROM clientes
        WHERE created_at BETWEEN ? AND ?
    ");
    $stmt->execute([$monthStart->format('Y-m-d H:i:s'), $monthEnd->format('Y-m-d H:i:s')]);
    $newClients = $stmt->fetch()['total'];

    // 4. Avaliação média
    $stmt = $pdo->prepare("
        SELECT AVG(avaliacao_media) as avg_rating
        FROM consultores
        WHERE status = 'ativo'
    ");
    $stmt->execute();
    $avgRating = round($stmt->fetch()['avg_rating'], 1);

    // Agenda da Semana
    $stmt = $pdo->prepare("
        SELECT a.data_hora, a.duracao, a.status, c.nome as cliente_nome, s.nome as servico_nome
        FROM agendamentos a
        JOIN clientes c ON a.cliente_id = c.id
        JOIN servicos s ON a.servico_id = s.id
        WHERE a.data_hora BETWEEN ? AND ?
        AND a.status IN ('pendente', 'confirmado', 'concluido')
        ORDER BY a.data_hora
    ");
    $stmt->execute([$weekStart->format('Y-m-d 00:00:00'), $weekEnd->format('Y-m-d 23:59:59')]);
    $weekAppointments = $stmt->fetchAll();

    $calendarData = [];
    for ($day = 1; $day <= 7; $day++) {
        $date = new DateTime("2025-06-0$day");
        $calendarData[$day] = [
            'day_name' => $date->format('D'),
            'day_number' => $day,
            'events' => []
        ];
    }

    foreach ($weekAppointments as $appt) {
        $apptDate = new DateTime($appt['data_hora']);
        $day = (int)$apptDate->format('j');
        if ($day >= 1 && $day <= 7) {
            $calendarData[$day]['events'][] = [
                'time' => $apptDate->format('H:i'),
                'title' => "{$appt['cliente_nome']} - {$appt['servico_nome']}",
                'status' => $appt['status']
            ];
        }
    }

    // Atividades Recentes
    $stmt = $pdo->prepare("
        (
            SELECT 'new_appointment' as type, a.created_at, c.nome as cliente_nome, s.nome as servico_nome
            FROM agendamentos a
            JOIN clientes c ON a.cliente_id = c.id
            JOIN servicos s ON a.servico_id = s.id
            WHERE a.status = 'confirmado'
        ) UNION (
            SELECT 'reagendamento' as type, a.updated_at as created_at, c.nome as cliente_nome, s.nome as servico_nome
            FROM agendamentos a
            JOIN clientes c ON a.cliente_id = c.id
            JOIN servicos s ON a.servico_id = s.id
            WHERE a.status = 'pendente' AND a.updated_at > a.created_at
        ) UNION (
            SELECT 'new_client' as type, c.created_at, c.nome as cliente_nome, NULL as servico_nome
            FROM clientes c
        ) UNION (
            SELECT 'cancelled_appointment' as type, a.updated_at as created_at, c.nome as cliente_nome, s.nome as servico_nome
            FROM agendamentos a
            JOIN clientes c ON a.cliente_id = c.id
            JOIN servicos s ON a.servico_id = s.id
            WHERE a.status = 'cancelado'
        )
        ORDER BY created_at DESC
        LIMIT 5
    ");
    $stmt->execute();
    $recentActivities = $stmt->fetchAll();

    $activityData = [];
    foreach ($recentActivities as $activity) {
        $timeAgo = (new DateTime())->diff(new DateTime($activity['created_at']));
        if ($timeAgo->days > 0) {
            $timeText = "Há {$timeAgo->days} dias";
        } elseif ($timeAgo->h > 0) {
            $timeText = "Há {$timeAgo->h} horas";
        } else {
            $timeText = "Há {$timeAgo->i} minutos";
        }

        $activityData[] = [
            'type' => $activity['type'],
            'description' => $activity['type'] === 'new_client' ? "Novo cliente registrado" : 
                            ($activity['type'] === 'new_appointment' ? "Novo agendamento confirmado" :
                            ($activity['type'] === 'reagendamento' ? "Agendamento reagendado" : "Agendamento cancelado")),
            'meta' => $activity['type'] === 'new_client' ? $activity['cliente_nome'] : 
                     "{$activity['cliente_nome']} - {$activity['servico_nome']}",
            'time' => $timeText
        ];
    }

    // Próximos Agendamentos
    $stmt = $pdo->prepare("
        SELECT a.id, a.data_hora, a.duracao, a.status, c.nome as cliente_nome, s.nome as servico_nome
        FROM agendamentos a
        JOIN clientes c ON a.cliente_id = c.id
        JOIN servicos s ON a.servico_id = s.id
        WHERE a.data_hora >= ?
        AND a.status IN ('pendente', 'confirmado')
        ORDER BY a.data_hora
        LIMIT 5
    ");
    $stmt->execute([$today->format('Y-m-d H:i:s')]);
    $upcomingAppointments = $stmt->fetchAll();

    $upcomingData = [];
    foreach ($upcomingAppointments as $appt) {
        $apptDate = new DateTime($appt['data_hora']);
        $todayStr = $today->format('Y-m-d');
        $tomorrow = (new DateTime())->modify('+1 day')->format('Y-m-d');
        $dayStr = $apptDate->format('Y-m-d') === $todayStr ? 'Hoje' :
                  ($apptDate->format('Y-m-d') === $tomorrow ? 'Amanhã' :
                  $apptDate->format('D, j M'));

        $upcomingData[] = [
            'id' => $appt['id'],
            'day' => $dayStr,
            'hour' => $apptDate->format('H:i'),
            'client' => $appt['cliente_nome'],
            'service' => $appt['servico_nome'],
            'duration' => $appt['duracao'] >= 120 ? '2 horas' : 
                         ($appt['duracao'] >= 90 ? '1h30min' : '1 hora')
        ];
    }

    // Retorna os dados
    echo json_encode([
        'success' => true,
        'stats' => [
            'appointmentsThisMonth' => $appointmentsThisMonth,
            'revenueThisMonth' => number_format($revenueThisMonth, 2, ',', '.'),
            'newClients' => $newClients,
            'avgRating' => $avgRating
        ],
        'calendar' => $calendarData,
        'activities' => $activityData,
        'upcoming' => $upcomingData
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erro ao carregar dados: ' . $e->getMessage()]);
}
?>