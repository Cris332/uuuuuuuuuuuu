<?php
header('Content-Type: application/json');
require_once 'config.php';

try {
    // Recebe os parâmetros via GET
    $consultant_id = isset($_GET['consultant_id']) ? sanitizeInput($_GET['consultant_id']) : null;
    $date = isset($_GET['date']) ? sanitizeInput($_GET['date']) : null;
    $service_id = isset($_GET['service_id']) ? sanitizeInput($_GET['service_id']) : null;

    if (!$consultant_id || !$date || !$service_id) {
        http_response_code(400);
        echo json_encode(['error' => 'Parâmetros incompletos']);
        exit;
    }

    // Valida formato da data
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        http_response_code(400);
        echo json_encode(['error' => 'Data inválida']);
        exit;
    }

    // Verifica se o serviço existe e obtém a duração
    $stmt = $pdo->prepare("SELECT duracao FROM servicos WHERE id = ? AND status = 'ativo'");
    $stmt->execute([$service_id]);
    $service = $stmt->fetch();
    if (!$service) {
        http_response_code(400);
        echo json_encode(['error' => 'Serviço inválido ou inativo']);
        exit;
    }
    $duration = $service['duracao'];

    // Verifica se o consultor existe e está ativo
    $stmt = $pdo->prepare("SELECT disponibilidade FROM consultores WHERE id = ? AND status = 'ativo'");
    $stmt->execute([$consultant_id]);
    $consultant = $stmt->fetch();
    if (!$consultant) {
        http_response_code(400);
        echo json_encode(['error' => 'Consultor inválido ou inativo']);
        exit;
    }

    // Obtém horários ocupados
    $stmt = $pdo->prepare("
        SELECT data_hora, duracao
        FROM agendamentos
        WHERE consultor_id = ?
        AND DATE(data_hora) = ?
        AND status IN ('pendente', 'confirmado')
    ");
    $stmt->execute([$consultant_id, $date]);
    $booked_slots = $stmt->fetchAll();

    // Define horários de trabalho padrão (baseado em disponibilidade: Seg-Sex, 09:00-18:00)
    $opening_hour = 9;
    $closing_hour = 18;
    $slot_interval = 30; // minutos
    $all_possible_times = [];

    for ($h = $opening_hour; $h < $closing_hour; $h++) {
        for ($m = 0; $m < 60; $m += $slot_interval) {
            $time = sprintf('%02d:%02d', $h, $m);
            $all_possible_times[] = $time;
        }
    }

    // Filtra horários disponíveis
    $available_times = [];
    foreach ($all_possible_times as $time) {
        $datetime = DateTime::createFromFormat('Y-m-d H:i', "$date $time");
        if (!$datetime) {
            continue;
        }

        // Verifica se o horário final está dentro do expediente
        $end_datetime = clone $datetime;
        $end_datetime->modify("+$duration minutes");
        if ($end_datetime->format('H:i') > sprintf('%02d:00', $closing_hour)) {
            continue;
        }

        // Verifica conflitos com agendamentos existentes
        $is_available = true;
        foreach ($booked_slots as $slot) {
            $slot_start = new DateTime($slot['data_hora']);
            $slot_end = clone $slot_start;
            $slot_end->modify("+{$slot['duracao']} minutes");

            if ($datetime < $slot_end && $end_datetime > $slot_start) {
                $is_available = false;
                break;
            }
        }

        if ($is_available) {
            $available_times[] = $time;
        }
    }

    // Retorna os horários disponíveis
    echo json_encode(['times' => $available_times]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erro ao buscar horários disponíveis: ' . $e->getMessage()]);
}
?>