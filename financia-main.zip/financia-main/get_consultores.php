<?php
header('Content-Type: application/json');
require_once 'config.php';

try {
    // Query para buscar consultores ativos e seus serviços
    $query = "
        SELECT DISTINCT 
            c.id,
            c.nome,
            c.especialidades,
            c.disponibilidade,
            c.status,
            GROUP_CONCAT(s.id) as servicos_ids,
            GROUP_CONCAT(s.nome) as servicos_nomes
        FROM consultores c
        JOIN consultores_servicos cs ON c.id = cs.consultor_id
        JOIN servicos s ON cs.servico_id = s.id
        WHERE c.status = 'ativo'
        GROUP BY c.id
        ORDER BY c.nome
    ";

    $stmt = $pdo->prepare($query);
    $stmt->execute();
    $consultores = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Formatar dados para o frontend
    $consultoresFormatados = array_map(function($consultor) {
        // Gerar um slug para o ID do frontend (ex: "carlos-silva")
        $slug = strtolower(
            preg_replace('/[^a-zA-Z0-9]+/', '-',
            iconv('UTF-8', 'ASCII//TRANSLIT', $consultor['nome'])
        ));

        return [
            'id' => $consultor['id'],
            'slug' => $slug,
            'nome' => $consultor['nome'],
            'especialidades' => $consultor['especialidades'],
            'disponibilidade' => $consultor['disponibilidade'],
            'servicos' => array_combine(
                explode(',', $consultor['servicos_ids']),
                explode(',', $consultor['servicos_nomes'])
            )
        ];
    }, $consultores);

    echo json_encode([
        'success' => true,
        'consultores' => $consultoresFormatados
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Erro ao carregar consultores: ' . $e->getMessage()
    ]);
}
