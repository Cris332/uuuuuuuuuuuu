document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('login-form');
    
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const rememberMe = document.getElementById('remember').checked;
        
        // For demo purposes, we'll use a hardcoded credential check
        // In a real application, this would be handled by the server
        if (username === 'admin@123' && password === 'admin123') {
            // Save to localStorage if remember me is checked
            if (rememberMe) {
                localStorage.setItem('financeConsultAuth', JSON.stringify({
                    username: username,
                    isAuthenticated: true,
                    timestamp: new Date().getTime()
                }));
            } else {
                // Use sessionStorage if not "remember me"
                sessionStorage.setItem('financeConsultAuth', JSON.stringify({
                    username: username,
                    isAuthenticated: true,
                    timestamp: new Date().getTime()
                }));
            }
            
            // Redirect to admin dashboard
            window.location.href = 'admin/dashboard.html';
        } else {
            // Show error message
            alert('Usuário ou senha incorretos. Por favor, tente novamente.');
            
            // Clear password field
            document.getElementById('password').value = '';
            document.getElementById('password').focus();
        }
    });
    
    // Check if user is already logged in
    function checkAuthStatus() {
        const authSession = sessionStorage.getItem('financeConsultAuth');
        const authLocal = localStorage.getItem('financeConsultAuth');
        
        if (authSession || authLocal) {
            const auth = JSON.parse(authSession || authLocal);
            
            // Check if the auth is still valid (24 hours)
            const now = new Date().getTime();
            const authTime = auth.timestamp;
            const hoursDiff = (now - authTime) / (1000 * 60 * 60);
            
            if (hoursDiff < 24 && auth.isAuthenticated) {
                // Redirect to admin dashboard
                window.location.href = 'admin/dashboard.html';
            } else {
                // Clear expired auth
                localStorage.removeItem('financeConsultAuth');
                sessionStorage.removeItem('financeConsultAuth');
            }
        }
    }
    
    // Check auth status on page load
    checkAuthStatus();
    
    // Handle forgot password link
    document.querySelector('.forgot-password').addEventListener('click', function(e) {
        e.preventDefault();
        alert('A funcionalidade de recuperação de senha será implementada em breve!');
    });
});
