document.addEventListener('DOMContentLoaded', function() {
    // Add hover effects for service cards
    const serviceCards = document.querySelectorAll('.service-card');
    
    serviceCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.cursor = 'pointer';
        });
        
        card.addEventListener('click', function() {
            // Highlight selected service
            serviceCards.forEach(c => c.classList.remove('selected'));
            this.classList.add('selected');
            
            // You could add more functionality here like showing a booking form
            // or redirecting to a service details page
        });
    });
    
    // Admin button functionality
    const adminButton = document.querySelector('.admin-button button');
    
    adminButton.addEventListener('click', function() {
        // Redirect to admin login page
        window.location.href = 'login.html';
    });
});
