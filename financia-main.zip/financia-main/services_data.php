<?php
header('Content-Type: application/json');
require_once 'config.php';

// Habilitar logs para depuração
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'C:/xampp/php/logs/php_error_log');
error_log('services_data.php: Iniciando requisição');

try {
    // Verificar método da requisição
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        error_log('services_data.php: Requisição POST recebida');
        $input = json_decode(file_get_contents('php://input'), true);
        if (isset($input['action']) && in_array($input['action'], ['activate', 'deactivate']) && isset($input['id'])) {
            $newStatus = $input['action'] === 'activate' ? 'ativo' : 'inativo';
            error_log('services_data.php: Alterando status do serviço ID ' . $input['id'] . ' para ' . $newStatus);
            $stmt = $pdo->prepare("UPDATE servicos SET status = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$newStatus, (int)$input['id']]);
            echo json_encode(['success' => true]);
            exit;
        }
        throw new Exception('Ação POST inválida');
    }

    // Parâmetros GET
    $status = isset($_GET['status']) ? trim($_GET['status']) : '';
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';

    error_log('services_data.php: Parâmetros recebidos - status: ' . $status . ', search: ' . $search);

    // Montar query base
    $query = "
        SELECT s.id, s.nome, s.descricao, s.duracao, s.preco, s.status,
               (SELECT COUNT(*) FROM agendamentos a 
                WHERE a.servico_id = s.id 
                AND YEAR(a.data_hora) = 2025 
                AND MONTH(a.data_hora) = 6) as agendamentos,
               (SELECT COUNT(DISTINCT a.consultor_id) FROM agendamentos a 
                WHERE a.servico_id = s.id) as consultores_disponiveis
        FROM servicos s
        WHERE 1=1
    ";
    $params = [];

    // Filtro por status
    if ($status && in_array($status, ['ativo', 'inativo'])) {
        $query .= " AND s.status = ?";
        $params[] = $status;
    }

    // Busca por nome
    if ($search) {
        $query .= " AND s.nome LIKE ?";
        $params[] = "%$search%";
    }

    // Ordenação
    $query .= " ORDER BY s.nome ASC";

    // Executar query
    error_log('services_data.php: Executando query: ' . $query);
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
    error_log('services_data.php: Serviços retornados: ' . count($services));

    // Formatar dados
    $data = array_map(function($service) {
        return [
            'id' => $service['id'],
            'nome' => $service['nome'],
            'descricao' => $service['descricao'],
            'duracao' => $service['duracao'],
            'preco' => number_format($service['preco'], 2, ',', '.'),
            'status' => $service['status'],
            'agendamentos' => $service['agendamentos'],
            'consultores_disponiveis' => $service['consultores_disponiveis']
        ];
    }, $services);

    // Resposta
    echo json_encode([
        'success' => true,
        'services' => $data,
        'total_records' => count($services)
    ]);
    error_log('services_data.php: Resposta enviada com sucesso');

} catch (Exception $e) {
    error_log('services_data.php: Erro capturado: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Erro ao carregar dados: ' . $e->getMessage()]);
}
?>