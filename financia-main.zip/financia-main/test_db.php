<?php
header('Content-Type: application/json');

// Habilitar logs e exibição de erros
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', 'C:/xampp/php/logs/php_error_log.txt');
ini_set('error_reporting', E_ALL);
error_log('test_db.php: Iniciando teste em ' . date('Y-m-d H:i:s'));

try {
    // Configuração direta
    $host = 'localhost';
    $dbname = 'financeconsult';
    $username = 'root';
    $password = '';

    error_log('test_db.php: Tentando conectar ao banco');
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    error_log('test_db.php: Conexão estabelecida');

    // Testar query trivial
    error_log('test_db.php: Executando SELECT 1');
    $stmt = $pdo->query('SELECT 1 AS test');
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    error_log('test_db.php: Resultado SELECT 1: ' . json_encode($result));

    // Resposta
    echo json_encode([
        'success' => true,
        'message' => 'Conexão PDO funcionando',
        'test_result' => $result['test']
    ]);

} catch (Exception $e) {
    error_log('test_db.php: Erro capturado: ' . $e->getMessage() . ' em linha ' . $e->getLine());
    http_response_code(500);
    echo json_encode(['error' => 'Erro: ' . $e->getMessage()]);
}
?>