/**
 * zoom-fix.js
 * Script para garantir que todas as páginas do sistema tenham o mesmo zoom
 */

document.addEventListener('DOMContentLoaded', function() {
    // Força o zoom para ser 1 (100%) em todas as páginas
    // Esta função será executada quando a página carregar
    function forcePageZoom() {
        // Verifica se estamos em uma página de calendário para usar como referência
        const isCalendarPage = window.location.href.includes('calendario.html');
        
        // Define o zoom para todas as páginas
        // Usando várias abordagens para garantir compatibilidade entre navegadores
        document.body.style.zoom = "1";
        document.body.style.transform = "scale(1)";
        document.body.style.transformOrigin = "0 0";
        
        // Adiciona uma classe ao body para aplicar estilos específicos de zoom
        document.body.classList.add('zoom-normalized');
        
        // Previne que o usuário use zoom com o teclado (Ctrl + / Ctrl -)
        window.addEventListener('keydown', function(e) {
            if ((e.ctrlKey || e.metaKey) && (e.key === '+' || e.key === '-' || e.key === '=')) {
                e.preventDefault();
                return false;
            }
        });
        
        // Previne zoom com a roda do mouse + Ctrl
        window.addEventListener('wheel', function(e) {
            if (e.ctrlKey || e.metaKey) {
                e.preventDefault();
                return false;
            }
        }, { passive: false });
    }
    
    // Executa a função quando a página carrega
    forcePageZoom();
    
    // Executa novamente se a janela for redimensionada
    window.addEventListener('resize', forcePageZoom);
});